<?php

/**
 * @version 1.6.0
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * @var array    $atts
 * @var callable $nl2br
 * @var string   $expert_avatar
 */


if ( ! empty( $atts['qa'] ) ): ?>
    <?php do_action( 'expert_review:before_qa', $atts ); ?>

    <div class="expert-review-qa">
        <?php if ( ! empty( $atts['qa_title'] ) && $atts['qa_show_title'] == 1 ): ?>
            <div class="expert-review-qa-header"><?php echo $atts['qa_title'] ?></div>
        <?php endif ?>
        <?php foreach ( $atts['qa'] as $qa ): ?>
            <?php
            $q = apply_filters( 'expert_review_qa:question', $nl2br( $qa['q'] ), $atts );
            $a = apply_filters( 'expert_review_qa:answer', $nl2br( $qa['a'] ), $atts );

            do_action( 'expert_review_questions_and_answers', [ $q, $a ] );
            ?>
            <div class="expert-review-qa-container">
                <div class="expert-review-qa__question"><?php echo $q ?></div>
                <div class="expert-review-qa__answer">
                    <div class="expert-review-qa__avatar"><?php echo $expert_avatar ?></div>
                    <div class="expert-review-qa__text"><?php echo $a ?></div>
                </div>
            </div>
        <?php endforeach ?>
    </div><!--.expert-review-qa-->

    <?php do_action( 'expert_review:after_qa', $atts ); ?>
<?php endif ?>
