<ul id="top_menu" class="menu">
				
<li id="menu-item-256" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-256"><a href="<?php echo e(route('karta-sajta')); ?>">Карта сайта</a></li>
<li id="menu-item-257" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-257"><a href="http://niksoncom.loc/pages/abaut">Автор</a></li>
<li id="menu-item-79" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-79"><a href="https://niksongames.ru/kanal-youtube-prohozhdenie-igr/">Видео</a></li>
 <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li id="menu-item-79" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-79">
                                    <a  href="<?php echo e(route('login')); ?>"><?php echo e(__('Войти')); ?></a>
                                </li>
                            <?php endif; ?>

                            
                        <?php else: ?>
							
						<?php if( Auth::user()->role == 4): ?>
<li id="menu-item-257" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-257"><a href="#">Добавить</a>
<ul class="sub-menu" style="display: none;">
	<li id="menu-item-277" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-277"><a href="<?php echo e(Route('post.create')); ?>">Статью</a></li>
	<li id="menu-item-278" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-278"><a href="<?php echo e(Route('page.create')); ?>">Страницу</a></li>
	<li id="menu-item-278" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-278"><a href="#">Категорию</a></li>
	<li id="menu-item-278" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-278"><a href="#">Пользователя</a></li>
</ul>
</li>
<?php endif; ?>
						<li id="menu-item-257" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-257"><a href="#"><?php echo e(Auth::user()->name); ?></a>
<ul class="sub-menu" style="display: none;">
	<li id="menu-item-277" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-277"><a href="/user/<?php echo e(Auth::user()->id); ?>">Профиль</a></li>
	<li id="menu-item-278" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-278"><a  href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Выход')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
</ul>
						
						
                        <?php endif; ?>
						


</ul><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/layouts/include/menu-main-container.blade.php ENDPATH**/ ?>