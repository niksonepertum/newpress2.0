<div id="wpshop_widget_articles-2" class="widget widget_wpshop_widget_articles"><div class="widget-header">Другие статьи автора</div><div class="widget-articles">
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/startovala-otkrytaya-beta-obnovleniya-1-43-dlya-euro-truck-simulator-2/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-330x140.jpeg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-330x140.jpeg 330w, https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-770x330.jpeg 770w" sizes="(max-width: 330px) 100vw, 330px">        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/startovala-otkrytaya-beta-obnovleniya-1-43-dlya-euro-truck-simulator-2/">Стартовала открытая бета обновления 1.43 для Euro Truck Simulator 2</a></div>

                    <div class="widget-article__description">
                Прошло совсем немного времени с тех пор, как мы в последний раз выпустили обновление            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/poslednie-novosti-kompyuternyh-igr/">Новости</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/majestic-5-server-otkryte-v-1700/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="Majestic 5 сервер открытье" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px">        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/majestic-5-server-otkryte-v-1700/">Majestic 5 сервер открытье в 17:00</a></div>

                    <div class="widget-article__description">
                Этот день настал! Сегодня 5 ноября Majestic 5 сервер и главный вопрос зачем? Онлайн            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/majestic-roleplay/majestic-5-server/">Majestic 5 сервер</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/obnovlenie-na-majestic-rp/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-330x140.png" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="обновление на Majestic rp наконец-то вышло" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-330x140.png 330w, https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-770x330.png 770w" sizes="(max-width: 330px) 100vw, 330px">        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/obnovlenie-na-majestic-rp/">обновление на Majestic rp наконец-то вышло</a></div>

                    <div class="widget-article__description">
                Друзья рад вам сообщить, что самое долгожданное обновление на Majestic rp наконец-то вышло! Сегодня            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/majestic-roleplay/">Majestic RolePlay</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/v-steam-vyshla-life-is-strange-before-the-storm-chto-nas-zhdet/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/10/dgpczmzdxfg-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/10/dgpczmzdxfg-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/10/dgpczmzdxfg-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px">        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/v-steam-vyshla-life-is-strange-before-the-storm-chto-nas-zhdet/">В Steam вышла life is strange before the storm, что нас ждет?</a></div>

                    <div class="widget-article__description">
                &nbsp; Оригинальная Life is Strange созданая DONTNOD Entertainment. Вышедшая в 2015 году и покорила            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/obzory-video-igr/">Обзоры видео игр</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 1</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/myparkur-prosto-slozhnyj-parkur/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/09/unknown-330x140.png" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="myparkur - просто сложный паркур" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/09/unknown-330x140.png 330w, https://niksongames.ru/wp-content/uploads/2021/09/unknown-770x330.png 770w" sizes="(max-width: 330px) 100vw, 330px">        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/myparkur-prosto-slozhnyj-parkur/">myparkur — просто сложный паркур</a></div>

                    <div class="widget-article__description">
                Простенькая игра паркур в реализации, но одновременно сложная для прохождения. Кто любит вызовы myparkur            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/skachat-igru-besplatno-bez-interneta/">Наши релизы</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/majestic-rp-3-server/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="КИНУЛИ НА БАБКИ majestic rp 3 сервер" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px">        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/majestic-rp-3-server/">КИНУЛИ НА БАБКИ? Маджестик говно!</a></div>

                    <div class="widget-article__description">
                Сегодня я расскажу как меня КИНУЛИ НА БАБКИ majestic rp 3 сервер, думаю будет            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/majestic-roleplay/majestic-3-server/">Majestic 3 сервер</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 6</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/kak-sdat-na-prava-na-majestic-rp/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="Как сдать на права на Majestic rp" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px">        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/kak-sdat-na-prava-na-majestic-rp/">Как сдать на права на Majestic rp? Правильные ответы</a></div>

                    <div class="widget-article__description">
                Многие новички на сереве задаются вопросом Как сдать на права на Majestic rp? Я            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/majestic-roleplay/">Majestic RolePlay</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/yddy-rp-gta-5-vsya-pravda-o-servere/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2020/02/2021-05-23_19-13-15-330x140.png" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2020/02/2021-05-23_19-13-15-330x140.png 330w, https://niksongames.ru/wp-content/uploads/2020/02/2021-05-23_19-13-15-770x330.png 770w" sizes="(max-width: 330px) 100vw, 330px">        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/yddy-rp-gta-5-vsya-pravda-o-servere/">YDDY RP GTA 5 Вся правда о Сервере</a></div>

                    <div class="widget-article__description">
                Честно не помню как я узнал о&nbsp;YDDY, но идея этого сервера мне понравилась и            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/obzory-video-igr/">Обзоры видео игр</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div></div></div><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/layouts/include/post-author.blade.php ENDPATH**/ ?>