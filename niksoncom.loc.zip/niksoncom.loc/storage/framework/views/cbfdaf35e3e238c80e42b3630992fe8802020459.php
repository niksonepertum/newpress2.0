

<?php $__env->startSection('content'); ?>



    
                    <div class="entry-image entry-image--big">
                <img width="1920" height="1080" src="<?php echo e($post->getPosts()); ?>" class="attachment-full size-full wp-post-image" alt="<?php echo e($post->title); ?>" loading="lazy" itemprop="image" srcset="<?php echo e($post->getPosts()); ?> 1920w, <?php echo e($post->getPosts()); ?> 
				300w, <?php echo e($post->getPosts()); ?> 1024w, <?php echo e($post->getPosts()); ?> 768w, <?php echo e($post->getPosts()); ?> 
				1536w, <?php echo e($post->getPosts()); ?> 250w, <?php echo e($post->getPosts()); ?> 550w, <?php echo e($post->getPosts()); ?> 800w, <?php echo e($post->getPosts()); ?> 320w, <?php echo e($post->getPosts()); ?> 533w, <?php echo e($post->getPosts()); ?> 889w" sizes="(max-width: 1920px) 100vw, 1920px">        
                <div class="entry-image__title">
                    <div class="breadcrumb" id="breadcrumbs"><span><span><a href="https://niksongames.ru/">Главная страница</a></span></span></div>
                                                                    <h1 itemprop="headline"><?php echo e($post->title); ?></h1>
                                            
                                            <div class="entry-meta">
                            <div class="entry-meta"><span class="entry-date"><span class="entry-label">Опубликовано:</span> <time itemprop="datePublished" datetime="2021-11-19"><?php echo e(Date::parse($post->created_at)->format('j F Y г.')); ?></time></span><span class="entry-category"><span class="hidden-xs">Рубрика:</span> <a href="https://niksongames.ru/poslednie-novosti-kompyuternyh-igr/" itemprop="articleSection">Новости</a></span><span class="entry-author"><span class="hidden-xs">Автор:</span> <span itemprop="author">Nikson</span></span><span class="b-share b-share--small">


<span class="b-share__ico b-share__vk js-share-link" data-uri="https://vk.com/share.php?url=https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__fb js-share-link" data-uri="https://www.facebook.com/sharer.php?u=https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__tw js-share-link" data-uri="https://twitter.com/share?text=ATS+DLC+Montana%3A+%D0%90%D0%BD%D0%BE%D0%BD%D1%81&amp;url=https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__ok js-share-link" data-uri="https://connect.ok.ru/dk?st.cmd=WidgetSharePreview&amp;service=odnoklassniki&amp;st.shareUrl=https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__whatsapp js-share-link js-share-link-no-window" data-uri="whatsapp://send?text=ATS+DLC+Montana%3A+%D0%90%D0%BD%D0%BE%D0%BD%D1%81%20https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__viber js-share-link js-share-link-no-window" data-uri="viber://forward?text=ATS+DLC+Montana%3A+%D0%90%D0%BD%D0%BE%D0%BD%D1%81%20https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__telegram js-share-link js-share-link-no-window" data-uri="https://t.me/share/url?url=https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F&amp;text=ATS+DLC+Montana%3A+%D0%90%D0%BD%D0%BE%D0%BD%D1%81"></span>

</span></div><!-- .entry-meta -->                        </div><!-- .entry-meta -->
                                    </div>

            </div>

    
	

            <div id="primary" class="content-area">
			
			<main id="main" class="site-main">
			<article id="post-258" class="post-258 post type-post status-publish format-standard has-post-thumbnail  category-poslednie-novosti-kompyuternyh-igr tag-ats tag-dlc">

    
        
    
	<?php echo $post->content; ?>

</article>



	
	<div class="entry-footer">
            <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
    
                
    <a href="https://niksongames.ru/tag/ats/" class="entry-meta__tag">ATS</a> <a href="https://niksongames.ru/tag/dlc/" class="entry-meta__tag">DLC</a> 
	
	<div class="b-r b-r--before-related"><div class="expert-review-likes expert-review-likes--style-button-1-color expert-review-likes--size-m js-expert-review-likes-button-container" data-post_id="258"><button class="expert-review-likes__button expert-review-likes__button--like js-expert-review-likes-button" data-type="like"><span class="expert-review-likes__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M103.6 202.7h-37c-9.2 0-16.6 7.4-16.6 16.6v240.1c0 9.2 7.4 16.6 16.6 16.6h36.9c9.2 0 16.6-7.4 16.6-16.6V219.3c.1-9.2-7.3-16.6-16.5-16.6zM425 202.7H290.2c-33.3 0 7.4-131.1 7.4-131.1 1.8-14.8 1.8-29.5-16.6-29.5h-16.6c-12.9 0-22.2 9.2-25.9 18.5 0 0-79.4 131.7-87.9 151.3-1.6 2.8-2.6 5.9-2.6 9.4v236.4c0 10.2 8.3 18.5 18.5 18.5H364c48-1.8 79.4-29.5 85-73.9l14.8-157c1.9-22.3-9.2-42.6-38.8-42.6z"></path></svg></span><span class="expert-review-likes__label">Мне нравится</span><span class="expert-review-likes__count js-expert-review-likes-count" data-count="0"></span></button><button class="expert-review-likes__button expert-review-likes__button--dislike js-expert-review-likes-button" data-type="dislike"><span class="expert-review-likes__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M103.6 318.3h-37c-9.2 0-16.6-7.4-16.6-16.6V61.6C50 52.4 57.4 45 66.6 45h36.9c9.2 0 16.6 7.4 16.6 16.6v240.1c.1 9.2-7.3 16.6-16.5 16.6zM425 318.3H290.2c-33.3 0 7.4 131.1 7.4 131.1 1.8 14.8 1.8 29.5-16.6 29.5h-16.6c-12.9 0-22.2-9.2-25.9-18.5 0 0-79.4-131.7-87.9-151.3-1.6-2.8-2.6-5.9-2.6-9.4V63.5c0-10.2 8.3-18.5 18.5-18.5H364c48 1.8 79.4 29.5 85 73.9l14.8 157c1.9 22.1-9.2 42.4-38.8 42.4z"></path></svg></span><span class="expert-review-likes__label">Не нравится</span><span class="expert-review-likes__count js-expert-review-dislikes-count" data-count="0"></span></button></div> </div>

    </div>
	
	<div class="author-box">
    <div class="author-box__ava">
        <img alt="" src="https://secure.gravatar.com/avatar/4ba14cd2d8795d01f288111fea593861?s=70&amp;d=mm&amp;r=g" srcset="https://secure.gravatar.com/avatar/4ba14cd2d8795d01f288111fea593861?s=140&amp;d=mm&amp;r=g 2x" class="avatar avatar-70 photo" height="70" width="70" loading="lazy">    </div>

    <div class="author-box__body">
        <div class="author-box__author">
            <a href="https://niksongames.ru/author/nikson/" target="_blank">Nikson</a><em>/ автор статьи</em>        </div>
        <div class="author-box__description">
            <!--noindex--><p>Я автор проекта NiksonGames - это не только канал на ютюб но и сервер в гта 5.</p>
<!--/noindex-->
        </div>
		 <div class="entry-rating">
        <div class="star-rating js-star-rating star-rating--score-0" data-post-id="258" data-rating-count="0" data-rating-sum="0" data-rating-value="0"><span class="star-rating-item js-star-rating-item" data-score="1"><svg aria-hidden="true" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" class="i-ico"><path fill="currentColor" d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z" class="ico-star"></path></svg></span><span class="star-rating-item js-star-rating-item" data-score="2"><svg aria-hidden="true" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" class="i-ico"><path fill="currentColor" d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z" class="ico-star"></path></svg></span><span class="star-rating-item js-star-rating-item" data-score="3"><svg aria-hidden="true" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" class="i-ico"><path fill="currentColor" d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z" class="ico-star"></path></svg></span><span class="star-rating-item js-star-rating-item" data-score="4"><svg aria-hidden="true" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" class="i-ico"><path fill="currentColor" d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z" class="ico-star"></path></svg></span><span class="star-rating-item js-star-rating-item" data-score="5"><svg aria-hidden="true" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" class="i-ico"><path fill="currentColor" d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z" class="ico-star"></path></svg></span></div>    
		
	</div> 

                        <div class="author-box__social">
                                            
                    
                    <div class="social-links">
                        <div class="social-buttons social-buttons--square social-buttons--circle social-buttons--small">
                            <span class="social-button social-button__youtube js-link" data-href="aHR0cHM6Ly93d3cueW91dHViZS5jb20vY2hhbm5lbC9VQ3FINmlKZm96eEp4Yzc3TmFZRFZieUE=" data-target="_blank"></span>                        </div>
                    </div>
                </div>
				
          
    </div>
</div>


<div class="b-share b-share--post">
        
                


<span class="b-share__ico b-share__vk js-share-link" data-uri="https://vk.com/share.php?url=https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__fb js-share-link" data-uri="https://www.facebook.com/sharer.php?u=https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__tw js-share-link" data-uri="https://twitter.com/share?text=ATS+DLC+Montana%3A+%D0%90%D0%BD%D0%BE%D0%BD%D1%81&amp;url=https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__ok js-share-link" data-uri="https://connect.ok.ru/dk?st.cmd=WidgetSharePreview&amp;service=odnoklassniki&amp;st.shareUrl=https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__whatsapp js-share-link js-share-link-no-window" data-uri="whatsapp://send?text=ATS+DLC+Montana%3A+%D0%90%D0%BD%D0%BE%D0%BD%D1%81%20https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__viber js-share-link js-share-link-no-window" data-uri="viber://forward?text=ATS+DLC+Montana%3A+%D0%90%D0%BD%D0%BE%D0%BD%D1%81%20https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F"></span>


<span class="b-share__ico b-share__telegram js-share-link js-share-link-no-window" data-uri="https://t.me/share/url?url=https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F&amp;text=ATS+DLC+Montana%3A+%D0%90%D0%BD%D0%BE%D0%BD%D1%81"></span>

</div>

<div class="b-related"><div class="b-related__header"><span>Вам также может быть интересно</span></div>
<div class="b-related__items">
<div id="post-246" class="post-card post-card-related post-246 post type-post status-publish format-standard has-post-thumbnail  category-poslednie-novosti-kompyuternyh-igr">
    <div class="post-card__image"><a href="https://niksongames.ru/startovala-otkrytaya-beta-obnovleniya-1-43-dlya-euro-truck-simulator-2/"><img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-330x140.jpeg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-330x140.jpeg 330w, https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-770x330.jpeg 770w" sizes="(max-width: 330px) 100vw, 330px"><div class="entry-meta"><span class="entry-category"><span>Новости</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></a></div><header class="entry-header"><div class="entry-title"><a href="https://niksongames.ru/startovala-otkrytaya-beta-obnovleniya-1-43-dlya-euro-truck-simulator-2/">Стартовала открытая бета обновления 1.43 для Euro Truck Simulator 2</a></div></header><div class="post-card__content"></div>
</div>

<div id="post-206" class="post-card post-card-related post-206 post type-post status-publish format-standard has-post-thumbnail  category-majestic-roleplay tag-majestic-rp tag-obnovlenie">
    <div class="post-card__image"><a href="https://niksongames.ru/obnovlenie-na-majestic-rp/"><img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-330x140.png" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="обновление на Majestic rp наконец-то вышло" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-330x140.png 330w, https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-770x330.png 770w" sizes="(max-width: 330px) 100vw, 330px"><div class="entry-meta"><span class="entry-category"><span>Majestic RolePlay</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></a></div><header class="entry-header"><div class="entry-title"><a href="https://niksongames.ru/obnovlenie-na-majestic-rp/">обновление на Majestic rp наконец-то вышло</a></div></header><div class="post-card__content"></div>
</div>



</div>
</div>

<div id="comments" class="comments-area">

		<div id="respond" class="comment-respond">
		<div id="reply-title" class="comment-reply-title">Добавить комментарий <small><a rel="nofollow" id="cancel-comment-reply-link" href="/ats-dlc-montana-anons/#respond" style="display:none;">Отменить ответ</a></small></div><form action="https://niksongames.ru/wp-comments-post.php" method="post" id="commentform" class="comment-form" novalidate=""><p class="logged-in-as"><a href="https://niksongames.ru/wp-admin/profile.php" aria-label="Вы вошли как Nikson. Изменить профиль.">Вы вошли как Nikson</a>. <a href="https://niksongames.ru/wp-login.php?action=logout&amp;redirect_to=https%3A%2F%2Fniksongames.ru%2Fats-dlc-montana-anons%2F&amp;_wpnonce=8d06d47bcb">Выйти?</a></p><p class="comment-form-comment"><label for="comment">Комментарий</label> <textarea id="comment" name="comment" cols="45" rows="8" maxlength="65525" required="required"></textarea></p><div class="comment-smiles js-comment-smiles"><img src="https://niksongames.ru/wp-content/themes/root/images/smilies/wink.png" alt=";-)"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/neutral.png" alt=":|"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/mad.png" alt=":x"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/twisted.png" alt=":twisted:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/smile.png" alt=":smile:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/eek.png" alt=":shock:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/sad.png" alt=":sad:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/rolleyes.png" alt=":roll:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/razz.png" alt=":razz:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/redface.png" alt=":oops:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/surprised.png" alt=":o"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/mrgreen.png" alt=":mrgreen:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/lol.png" alt=":lol:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/idea.png" alt=":idea:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/biggrin.png" alt=":grin:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/evil.png" alt=":evil:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/cry.png" alt=":cry:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/cool.png" alt=":cool:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/arrow.png" alt=":arrow:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/confused.png" alt=":???:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/question.png" alt=":?:"> <img src="https://niksongames.ru/wp-content/themes/root/images/smilies/exclaim.png" alt=":!:"> </div><p class="form-submit"><input name="submit" type="submit" id="submit" class="submit" value="Отправить комментарий"> <input type="hidden" name="comment_post_ID" value="258" id="comment_post_ID">
<input type="hidden" name="comment_parent" id="comment_parent" value="0">
</p><input type="hidden" id="_wp_unfiltered_html_comment_disabled" name="_wp_unfiltered_html_comment" value="9c9962a6b0"><script>(function(){if(window===window.parent){document.getElementById('_wp_unfiltered_html_comment_disabled').name='_wp_unfiltered_html_comment';}})();</script>
</form>	</div><!-- #respond -->
	
</div>


			
			</main>
			
			
			
			</div>
			



    
        
    
	


		

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog-show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/posts/show.blade.php ENDPATH**/ ?>