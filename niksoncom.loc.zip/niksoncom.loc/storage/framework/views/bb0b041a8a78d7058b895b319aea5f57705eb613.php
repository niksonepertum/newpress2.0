

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Поддержи нашь проект</div>
                
                <div class="card-body">





                    <br />  <br />



                    <?php if( Auth::user()->role == 4): ?>

                    <div class="btn-group">
                      <a href="#" class="btn btn-sm btn-outline-secondary">Редактировать</a>
                      <a href="#" class="btn btn-sm btn-outline-secondary">Удалить</a>

                    </div>

                      <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/page/donate.blade.php ENDPATH**/ ?>