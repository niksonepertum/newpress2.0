<?php $__env->startSection('content'); ?>
<main id="main" class="site-main">

		
			
            
            
            
<div class="posts-container">

    
<div id="post-258" class="post-box post-258 post type-post status-publish format-standard has-post-thumbnail  category-poslednie-novosti-kompyuternyh-igr tag-ats tag-dlc" itemscope itemtype="http://schema.org/BlogPosting">
	<header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/ats-dlc-montana-anons/">ATS DLC Montana: Анонс</a></span></div><div class="entry-meta"><span class="entry-date"><time itemprop="datePublished" datetime="2021-11-19">19.11.2021</time></span><span class="entry-category"><span class="hidden-xs">Рубрика:</span> <a href="https://niksongames.ru/poslednie-novosti-kompyuternyh-igr/" itemprop="articleSection">Новости</a></span><span class="entry-author"><span class="hidden-xs">Автор:</span> <span itemprop="author">Nikson</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></header><div class="entry-image"><a href="https://niksongames.ru/ats-dlc-montana-anons/"><img width="770" height="330" src="https://niksongames.ru/wp-content/uploads/2021/11/xf9ito2nfp4-770x330.jpg" class="attachment-thumb-big size-thumb-big wp-post-image" alt="ATS DLC Montana: Анонс" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/11/xf9ito2nfp4-770x330.jpg 770w, https://niksongames.ru/wp-content/uploads/2021/11/xf9ito2nfp4-330x140.jpg 330w" sizes="(max-width: 770px) 100vw, 770px" /></a></div><div class="post-box__content" itemprop="articleBody">После загрузки загадочного видео-трейлера, в котором наша 2D-художница Энни нарисовала красивую сцену с горами и флорой, сегодня мы рады сообщить вам, на каком именно состоянии было основано это произведение</div><footer class="post-box__footer"><a href="https://niksongames.ru/ats-dlc-montana-anons/" class="entry-footer__more">Читать полностью</a></footer>
            	<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="https://niksongames.ru/ats-dlc-montana-anons/" content="ATS DLC Montana: Анонс">
	<meta itemprop="dateModified" content="2021-11-19">
    <div itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
    
</div>
<div id="post-246" class="post-box post-246 post type-post status-publish format-standard has-post-thumbnail  category-poslednie-novosti-kompyuternyh-igr" itemscope itemtype="http://schema.org/BlogPosting">
	<header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/startovala-otkrytaya-beta-obnovleniya-1-43-dlya-euro-truck-simulator-2/">Стартовала открытая бета обновления 1.43 для Euro Truck Simulator 2</a></span></div><div class="entry-meta"><span class="entry-date"><time itemprop="datePublished" datetime="2021-11-12">12.11.2021</time></span><span class="entry-category"><span class="hidden-xs">Рубрика:</span> <a href="https://niksongames.ru/poslednie-novosti-kompyuternyh-igr/" itemprop="articleSection">Новости</a></span><span class="entry-author"><span class="hidden-xs">Автор:</span> <span itemprop="author">Nikson</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></header><div class="entry-image"><a href="https://niksongames.ru/startovala-otkrytaya-beta-obnovleniya-1-43-dlya-euro-truck-simulator-2/"><img width="770" height="330" src="https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-770x330.jpeg" class="attachment-thumb-big size-thumb-big wp-post-image" alt="" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-770x330.jpeg 770w, https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-330x140.jpeg 330w" sizes="(max-width: 770px) 100vw, 770px" /></a></div><div class="post-box__content" itemprop="articleBody">Прошло совсем немного времени с тех пор, как мы в последний раз выпустили обновление для наших игр-симуляторов грузовиков, однако мы рады сообщить вам, что начался новый цикл открытого</div><footer class="post-box__footer"><a href="https://niksongames.ru/startovala-otkrytaya-beta-obnovleniya-1-43-dlya-euro-truck-simulator-2/" class="entry-footer__more">Читать полностью</a></footer>
            	<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="https://niksongames.ru/startovala-otkrytaya-beta-obnovleniya-1-43-dlya-euro-truck-simulator-2/" content="Стартовала открытая бета обновления 1.43 для Euro Truck Simulator 2">
	<meta itemprop="dateModified" content="2021-11-12">
    <div itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
    
</div>
<div id="post-229" class="post-box post-229 post type-post status-publish format-standard has-post-thumbnail  category-majestic-5-server category-majestic-roleplay tag-5-sejver tag-majestic tag-roleplay tag-egor-krid" itemscope itemtype="http://schema.org/BlogPosting">
	<header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/majestic-5-server-otkryte-v-1700/">Majestic 5 сервер открытье в 17:00</a></span></div><div class="entry-meta"><span class="entry-date"><time itemprop="datePublished" datetime="2021-11-05">05.11.2021</time></span><span class="entry-category"><span class="hidden-xs">Рубрика:</span> <a href="https://niksongames.ru/majestic-roleplay/majestic-5-server/" itemprop="articleSection">Majestic 5 сервер</a></span><span class="entry-author"><span class="hidden-xs">Автор:</span> <span itemprop="author">Nikson</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></header><div class="entry-image"><a href="https://niksongames.ru/majestic-5-server-otkryte-v-1700/"><img width="770" height="330" src="https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-770x330.jpg" class="attachment-thumb-big size-thumb-big wp-post-image" alt="Majestic 5 сервер открытье" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-770x330.jpg 770w, https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-330x140.jpg 330w" sizes="(max-width: 770px) 100vw, 770px" /></a></div><div class="post-box__content" itemprop="articleBody">Этот день настал! Сегодня 5 ноября Majestic 5 сервер и главный вопрос зачем? Онлайн перед обновлением не превышал 4 &#8212; 5000 человек на всех серверах проекта. Остались только</div><footer class="post-box__footer"><a href="https://niksongames.ru/majestic-5-server-otkryte-v-1700/" class="entry-footer__more">Читать полностью</a></footer>
            	<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="https://niksongames.ru/majestic-5-server-otkryte-v-1700/" content="Majestic 5 сервер открытье в 17:00">
	<meta itemprop="dateModified" content="2021-11-07">
    <div itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
    
</div>
<div id="post-206" class="post-box post-206 post type-post status-publish format-standard has-post-thumbnail  category-majestic-roleplay tag-majestic-rp tag-obnovlenie" itemscope itemtype="http://schema.org/BlogPosting">
	<header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/obnovlenie-na-majestic-rp/">обновление на Majestic rp наконец-то вышло</a></span></div><div class="entry-meta"><span class="entry-date"><time itemprop="datePublished" datetime="2021-11-01">01.11.2021</time></span><span class="entry-category"><span class="hidden-xs">Рубрика:</span> <a href="https://niksongames.ru/majestic-roleplay/" itemprop="articleSection">Majestic RolePlay</a></span><span class="entry-author"><span class="hidden-xs">Автор:</span> <span itemprop="author">Nikson</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></header><div class="entry-image"><a href="https://niksongames.ru/obnovlenie-na-majestic-rp/"><img width="770" height="330" src="https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-770x330.png" class="attachment-thumb-big size-thumb-big wp-post-image" alt="обновление на Majestic rp наконец-то вышло" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-770x330.png 770w, https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-330x140.png 330w" sizes="(max-width: 770px) 100vw, 770px" /></a></div><div class="post-box__content" itemprop="articleBody">Друзья рад вам сообщить, что самое долгожданное обновление на Majestic rp наконец-то вышло! Сегодня в где-то в 12 часов по мск вышел анонс обновления на официальном канале маджестик</div><footer class="post-box__footer"><a href="https://niksongames.ru/obnovlenie-na-majestic-rp/" class="entry-footer__more">Читать полностью</a></footer>
            	<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="https://niksongames.ru/obnovlenie-na-majestic-rp/" content="обновление на Majestic rp наконец-то вышло">
	<meta itemprop="dateModified" content="2021-11-02">
    <div itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
    
</div>
<div id="post-201" class="post-box post-201 post type-post status-publish format-standard has-post-thumbnail  category-obzory-video-igr" itemscope itemtype="http://schema.org/BlogPosting">
	<header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/v-steam-vyshla-life-is-strange-before-the-storm-chto-nas-zhdet/">В Steam вышла life is strange before the storm, что нас ждет?</a></span></div><div class="entry-meta"><span class="entry-date"><time itemprop="datePublished" datetime="2021-10-22">22.10.2021</time></span><span class="entry-category"><span class="hidden-xs">Рубрика:</span> <a href="https://niksongames.ru/obzory-video-igr/" itemprop="articleSection">Обзоры видео игр</a></span><span class="entry-author"><span class="hidden-xs">Автор:</span> <span itemprop="author">Nikson</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 1</span></span></div></header><div class="entry-image"><a href="https://niksongames.ru/v-steam-vyshla-life-is-strange-before-the-storm-chto-nas-zhdet/"><img width="770" height="330" src="https://niksongames.ru/wp-content/uploads/2021/10/dgpczmzdxfg-770x330.jpg" class="attachment-thumb-big size-thumb-big wp-post-image" alt="" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/10/dgpczmzdxfg-770x330.jpg 770w, https://niksongames.ru/wp-content/uploads/2021/10/dgpczmzdxfg-330x140.jpg 330w" sizes="(max-width: 770px) 100vw, 770px" /></a></div><div class="post-box__content" itemprop="articleBody">&nbsp; Оригинальная Life is Strange созданая DONTNOD Entertainment. Вышедшая в 2015 году и покорила сердца игроков во всем мире! Игрока ждали старые друзья, перемещение во времени, новые проблемы</div><footer class="post-box__footer"><a href="https://niksongames.ru/v-steam-vyshla-life-is-strange-before-the-storm-chto-nas-zhdet/" class="entry-footer__more">Читать полностью</a></footer>
            	<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="https://niksongames.ru/v-steam-vyshla-life-is-strange-before-the-storm-chto-nas-zhdet/" content="В Steam вышла life is strange before the storm, что нас ждет?">
	<meta itemprop="dateModified" content="2021-10-22">
    <div itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
    
</div>
<div id="post-158" class="post-box post-158 post type-post status-publish format-standard has-post-thumbnail  category-skachat-igru-besplatno-bez-interneta" itemscope itemtype="http://schema.org/BlogPosting">
	<header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/myparkur-prosto-slozhnyj-parkur/">myparkur &#8212; просто сложный паркур</a></span></div><div class="entry-meta"><span class="entry-date"><time itemprop="datePublished" datetime="2021-09-20">20.09.2021</time></span><span class="entry-category"><span class="hidden-xs">Рубрика:</span> <a href="https://niksongames.ru/skachat-igru-besplatno-bez-interneta/" itemprop="articleSection">Наши релизы</a></span><span class="entry-author"><span class="hidden-xs">Автор:</span> <span itemprop="author">Nikson</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></header><div class="entry-image"><a href="https://niksongames.ru/myparkur-prosto-slozhnyj-parkur/"><img width="770" height="330" src="https://niksongames.ru/wp-content/uploads/2021/09/unknown-770x330.png" class="attachment-thumb-big size-thumb-big wp-post-image" alt="myparkur - просто сложный паркур" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/09/unknown-770x330.png 770w, https://niksongames.ru/wp-content/uploads/2021/09/unknown-330x140.png 330w" sizes="(max-width: 770px) 100vw, 770px" /></a></div><div class="post-box__content" itemprop="articleBody">Простенькая игра паркур в реализации, но одновременно сложная для прохождения. Кто любит вызовы myparkur вам обязательно понравится. Я лично ее прошел на стриме друзья! М/не было сложно потому,</div><footer class="post-box__footer"><a href="https://niksongames.ru/myparkur-prosto-slozhnyj-parkur/" class="entry-footer__more">Читать полностью</a></footer>
            	<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="https://niksongames.ru/myparkur-prosto-slozhnyj-parkur/" content="myparkur &#8212; просто сложный паркур">
	<meta itemprop="dateModified" content="2021-09-20">
    <div itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
    
</div>
<div id="post-43" class="post-box post-43 post type-post status-publish format-standard has-post-thumbnail  category-majestic-3-server category-majestic-roleplay tag-majestic tag-rp tag-kinuli" itemscope itemtype="http://schema.org/BlogPosting">
	<header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/majestic-rp-3-server/">КИНУЛИ НА БАБКИ? Маджестик говно!</a></span></div><div class="entry-meta"><span class="entry-date"><time itemprop="datePublished" datetime="2021-08-18">18.08.2021</time></span><span class="entry-category"><span class="hidden-xs">Рубрика:</span> <a href="https://niksongames.ru/majestic-roleplay/majestic-3-server/" itemprop="articleSection">Majestic 3 сервер</a></span><span class="entry-author"><span class="hidden-xs">Автор:</span> <span itemprop="author">Nikson</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 6</span></span></div></header><div class="entry-image"><a href="https://niksongames.ru/majestic-rp-3-server/"><img width="770" height="330" src="https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-770x330.jpg" class="attachment-thumb-big size-thumb-big wp-post-image" alt="КИНУЛИ НА БАБКИ majestic rp 3 сервер" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-770x330.jpg 770w, https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-330x140.jpg 330w" sizes="(max-width: 770px) 100vw, 770px" /></a></div><div class="post-box__content" itemprop="articleBody">Сегодня я расскажу как меня КИНУЛИ НА БАБКИ majestic rp 3 сервер, думаю будет интересно как новичкам так и опытным игрокам в онлайн игры. Активно играю на Маджестик</div><footer class="post-box__footer"><a href="https://niksongames.ru/majestic-rp-3-server/" class="entry-footer__more">Читать полностью</a></footer>
            	<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="https://niksongames.ru/majestic-rp-3-server/" content="КИНУЛИ НА БАБКИ? Маджестик говно!">
	<meta itemprop="dateModified" content="2021-11-07">
    <div itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
    
</div>
<div id="post-40" class="post-box post-40 post type-post status-publish format-standard has-post-thumbnail  category-majestic-roleplay tag-majestic tag-majestic-rp tag-otvety tag-prava" itemscope itemtype="http://schema.org/BlogPosting">
	<header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/kak-sdat-na-prava-na-majestic-rp/">Как сдать на права на Majestic rp? Правильные ответы</a></span></div><div class="entry-meta"><span class="entry-date"><time itemprop="datePublished" datetime="2021-08-16">16.08.2021</time></span><span class="entry-category"><span class="hidden-xs">Рубрика:</span> <a href="https://niksongames.ru/majestic-roleplay/" itemprop="articleSection">Majestic RolePlay</a></span><span class="entry-author"><span class="hidden-xs">Автор:</span> <span itemprop="author">Nikson</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></header><div class="entry-image"><a href="https://niksongames.ru/kak-sdat-na-prava-na-majestic-rp/"><img width="770" height="330" src="https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-770x330.jpg" class="attachment-thumb-big size-thumb-big wp-post-image" alt="Как сдать на права на Majestic rp" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-770x330.jpg 770w, https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-330x140.jpg 330w" sizes="(max-width: 770px) 100vw, 770px" /></a></div><div class="post-box__content" itemprop="articleBody">Многие новички на сереве задаются вопросом Как сдать на права на Majestic rp? Я лично потратил на это 50,000 &#8212; 70,000$, что довольно много для новичка и сдавать</div><footer class="post-box__footer"><a href="https://niksongames.ru/kak-sdat-na-prava-na-majestic-rp/" class="entry-footer__more">Читать полностью</a></footer>
            	<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="https://niksongames.ru/kak-sdat-na-prava-na-majestic-rp/" content="Как сдать на права на Majestic rp? Правильные ответы">
	<meta itemprop="dateModified" content="2021-10-14">
    <div itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
    
</div>
<div id="post-1" class="post-box post-1 post type-post status-publish format-standard has-post-thumbnail  category-obzory-video-igr tag-gta-5 tag-gta-5-rp tag-yddy tag-yddyrp" itemscope itemtype="http://schema.org/BlogPosting">
	<header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/yddy-rp-gta-5-vsya-pravda-o-servere/">YDDY RP GTA 5 Вся правда о Сервере</a></span></div><div class="entry-meta"><span class="entry-date"><time itemprop="datePublished" datetime="2020-02-12">12.02.2020</time></span><span class="entry-category"><span class="hidden-xs">Рубрика:</span> <a href="https://niksongames.ru/obzory-video-igr/" itemprop="articleSection">Обзоры видео игр</a></span><span class="entry-author"><span class="hidden-xs">Автор:</span> <span itemprop="author">Nikson</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></header><div class="entry-image"><a href="https://niksongames.ru/yddy-rp-gta-5-vsya-pravda-o-servere/"><img width="770" height="330" src="https://niksongames.ru/wp-content/uploads/2020/02/2021-05-23_19-13-15-770x330.png" class="attachment-thumb-big size-thumb-big wp-post-image" alt="" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2020/02/2021-05-23_19-13-15-770x330.png 770w, https://niksongames.ru/wp-content/uploads/2020/02/2021-05-23_19-13-15-330x140.png 330w" sizes="(max-width: 770px) 100vw, 770px" /></a></div><div class="post-box__content" itemprop="articleBody">Честно не помню как я узнал о YDDY, но идея этого сервера мне понравилась и нравится досихпор. Что такое YDDY RP GTA 5? Это если вкратце аналог таких известных проектов как </div><footer class="post-box__footer"><a href="https://niksongames.ru/yddy-rp-gta-5-vsya-pravda-o-servere/" class="entry-footer__more">Читать полностью</a></footer>
            	<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="https://niksongames.ru/yddy-rp-gta-5-vsya-pravda-o-servere/" content="YDDY RP GTA 5 Вся правда о Сервере">
	<meta itemprop="dateModified" content="2021-08-15">
    <div itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
    
</div>
</div>
            
            

        
		</main><!-- #main -->
	</div><!-- #primary -->


<aside id="secondary" class="widget-area" itemscope itemtype="http://schema.org/WPSideBar">

    
	<div id="search-2" class="widget widget_search">
<form role="search" method="get" id="searchform_4033" action="https://niksongames.ru/" class="search-form">
    <label class="screen-reader-text" for="s_4033">Поиск: </label>
    <input type="text" value="" name="s" id="s_4033" class="search-form__text">
    <button type="submit" id="searchsubmit_4033" class="search-form__submit"></button>
</form></div><div id="block-3" class="widget widget_block">
<ul class="wp-block-social-links is-style-pill-shape"></ul>
</div><div id="block-5" class="widget widget_block">
<div class="wp-block-group"><div class="wp-block-group__inner-container"></div></div>
</div><div id="wpshop_widget_articles-2" class="widget widget_wpshop_widget_articles"><div class="widget-header">Что по читать</div><div class="widget-articles">
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/ats-dlc-montana-anons/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/11/xf9ito2nfp4-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="ATS DLC Montana: Анонс" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/11/xf9ito2nfp4-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/11/xf9ito2nfp4-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px" />        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/ats-dlc-montana-anons/">ATS DLC Montana: Анонс</a></div>

                    <div class="widget-article__description">
                После загрузки загадочного видео-трейлера, в котором наша 2D-художница Энни нарисовала красивую сцену с горами и            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/poslednie-novosti-kompyuternyh-igr/">Новости</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/startovala-otkrytaya-beta-obnovleniya-1-43-dlya-euro-truck-simulator-2/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-330x140.jpeg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-330x140.jpeg 330w, https://niksongames.ru/wp-content/uploads/2021/11/oujm03k-7pxmsax3qzfoxq-770x330.jpeg 770w" sizes="(max-width: 330px) 100vw, 330px" />        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/startovala-otkrytaya-beta-obnovleniya-1-43-dlya-euro-truck-simulator-2/">Стартовала открытая бета обновления 1.43 для Euro Truck Simulator 2</a></div>

                    <div class="widget-article__description">
                Прошло совсем немного времени с тех пор, как мы в последний раз выпустили обновление            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/poslednie-novosti-kompyuternyh-igr/">Новости</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/majestic-5-server-otkryte-v-1700/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="Majestic 5 сервер открытье" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px" />        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/majestic-5-server-otkryte-v-1700/">Majestic 5 сервер открытье в 17:00</a></div>

                    <div class="widget-article__description">
                Этот день настал! Сегодня 5 ноября Majestic 5 сервер и главный вопрос зачем? Онлайн            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/majestic-roleplay/majestic-5-server/">Majestic 5 сервер</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/obnovlenie-na-majestic-rp/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-330x140.png" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="обновление на Majestic rp наконец-то вышло" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-330x140.png 330w, https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-770x330.png 770w" sizes="(max-width: 330px) 100vw, 330px" />        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/obnovlenie-na-majestic-rp/">обновление на Majestic rp наконец-то вышло</a></div>

                    <div class="widget-article__description">
                Друзья рад вам сообщить, что самое долгожданное обновление на Majestic rp наконец-то вышло! Сегодня            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/majestic-roleplay/">Majestic RolePlay</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/v-steam-vyshla-life-is-strange-before-the-storm-chto-nas-zhdet/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/10/dgpczmzdxfg-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/10/dgpczmzdxfg-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/10/dgpczmzdxfg-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px" />        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/v-steam-vyshla-life-is-strange-before-the-storm-chto-nas-zhdet/">В Steam вышла life is strange before the storm, что нас ждет?</a></div>

                    <div class="widget-article__description">
                &nbsp; Оригинальная Life is Strange созданая DONTNOD Entertainment. Вышедшая в 2015 году и покорила            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/obzory-video-igr/">Обзоры видео игр</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 1</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/myparkur-prosto-slozhnyj-parkur/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/09/unknown-330x140.png" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="myparkur - просто сложный паркур" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/09/unknown-330x140.png 330w, https://niksongames.ru/wp-content/uploads/2021/09/unknown-770x330.png 770w" sizes="(max-width: 330px) 100vw, 330px" />        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/myparkur-prosto-slozhnyj-parkur/">myparkur &#8212; просто сложный паркур</a></div>

                    <div class="widget-article__description">
                Простенькая игра паркур в реализации, но одновременно сложная для прохождения. Кто любит вызовы myparkur            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/skachat-igru-besplatno-bez-interneta/">Наши релизы</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/majestic-rp-3-server/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="КИНУЛИ НА БАБКИ majestic rp 3 сервер" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px" />        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/majestic-rp-3-server/">КИНУЛИ НА БАБКИ? Маджестик говно!</a></div>

                    <div class="widget-article__description">
                Сегодня я расскажу как меня КИНУЛИ НА БАБКИ majestic rp 3 сервер, думаю будет            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/majestic-roleplay/majestic-3-server/">Majestic 3 сервер</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 6</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/kak-sdat-na-prava-na-majestic-rp/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="Как сдать на права на Majestic rp" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px" />        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/kak-sdat-na-prava-na-majestic-rp/">Как сдать на права на Majestic rp? Правильные ответы</a></div>

                    <div class="widget-article__description">
                Многие новички на сереве задаются вопросом Как сдать на права на Majestic rp? Я            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/majestic-roleplay/">Majestic RolePlay</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div>
<div class="widget-article widget-article--normal">
        <div class="widget-article__image">
        <a href="https://niksongames.ru/yddy-rp-gta-5-vsya-pravda-o-servere/">
            <img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2020/02/2021-05-23_19-13-15-330x140.png" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="" loading="lazy" srcset="https://niksongames.ru/wp-content/uploads/2020/02/2021-05-23_19-13-15-330x140.png 330w, https://niksongames.ru/wp-content/uploads/2020/02/2021-05-23_19-13-15-770x330.png 770w" sizes="(max-width: 330px) 100vw, 330px" />        </a>
    </div>
    
    <div class="widget-article__body">
        <div class="widget-article__title"><a href="https://niksongames.ru/yddy-rp-gta-5-vsya-pravda-o-servere/">YDDY RP GTA 5 Вся правда о Сервере</a></div>

                    <div class="widget-article__description">
                Честно не помню как я узнал о YDDY, но идея этого сервера мне понравилась и            </div>
        

                    <div class="entry-meta">
                                    <span class="entry-category">
                        <a href="https://niksongames.ru/obzory-video-igr/">Обзоры видео игр</a>                    </span>
                
                                    <span class="entry-meta__info">
                                                    <span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span>
                                                                    </span>
                            </div>
            </div>
</div></div></div><div id="categories-2" class="widget widget_categories"><div class="widget-header">Рубрики</div>
			<ul>
					<li class="cat-item cat-item-52"><a href="https://niksongames.ru/majestic-roleplay/majestic-3-server/" title="Если вам не нужен красивый статик на сервере и вы цените стабильность majestic 3 сервер - это ваш выбор А стартовать лучше с нашей семьёй на сервере.">Majestic 3 сервер</a>
</li>
	<li class="cat-item cat-item-51"><a href="https://niksongames.ru/majestic-roleplay/majestic-5-server/" title="Хотите зайти на Majestic? Поздравляю вас сейчас самое лучшее время majestic 5 сервер открыт! Новая жизнь новый штат. Новые друзья.">Majestic 5 сервер</a>
</li>
	<li class="cat-item cat-item-7"><a href="https://niksongames.ru/majestic-roleplay/" title="Majestic RolePlay - это cервер, разработан на платформе RAGE Multiplayer (Рейдж Мультиплеер), который дает возможность отыгрывать выбранную роль в виртуальной вселенной, подчиняясь правилам реальной жизни. Станьте политиком, бандитом, бизнесменом, таксистом, рабочим на заводе, полицейским, в общем - кем угодно.

Что такое RolePlay? Направление игры, где каждый созданный игроком персонаж, отыгрывает заранее продуманную роль или сценарий. Индивидуальные и коллективные действия игроков создают ролевую ситуацию, участники которой отыгрывают собственных персонажей, руководствуясь характером своей роли в рамках игровых реалий.">Majestic RolePlay</a>
</li>
	<li class="cat-item cat-item-40"><a href="https://niksongames.ru/skachat-igru-besplatno-bez-interneta/">Наши релизы</a>
</li>
	<li class="cat-item cat-item-10"><a href="https://niksongames.ru/poslednie-novosti-kompyuternyh-igr/">Новости</a>
</li>
	<li class="cat-item cat-item-1"><a href="https://niksongames.ru/obzory-video-igr/">Обзоры видео игр</a>
</li>
			</ul>

			</div><div id="archives-2" class="widget widget_archive"><div class="widget-header">Архивы</div>
			<ul>
					<li><a href='https://niksongames.ru/2021/11/'>Ноябрь 2021</a></li>
	<li><a href='https://niksongames.ru/2021/10/'>Октябрь 2021</a></li>
	<li><a href='https://niksongames.ru/2021/09/'>Сентябрь 2021</a></li>
	<li><a href='https://niksongames.ru/2021/08/'>Август 2021</a></li>
	<li><a href='https://niksongames.ru/2020/02/'>Февраль 2020</a></li>
			</ul>

			</div><div id="block-2" class="widget widget_block widget_tag_cloud"><p class="wp-block-tag-cloud"><a href="https://niksongames.ru/tag/5-sejver/" class="tag-cloud-link tag-link-48 tag-link-position-1" style="font-size: 8pt;" aria-label="5 Сейвер (1 элемент)">5 Сейвер</a>
<a href="https://niksongames.ru/tag/ats/" class="tag-cloud-link tag-link-55 tag-link-position-2" style="font-size: 8pt;" aria-label="ATS (1 элемент)">ATS</a>
<a href="https://niksongames.ru/tag/dlc/" class="tag-cloud-link tag-link-56 tag-link-position-3" style="font-size: 8pt;" aria-label="DLC (1 элемент)">DLC</a>
<a href="https://niksongames.ru/tag/gta-5/" class="tag-cloud-link tag-link-3 tag-link-position-4" style="font-size: 8pt;" aria-label="GTA 5 (1 элемент)">GTA 5</a>
<a href="https://niksongames.ru/tag/gta-5-rp/" class="tag-cloud-link tag-link-4 tag-link-position-5" style="font-size: 8pt;" aria-label="GTA 5 RP (1 элемент)">GTA 5 RP</a>
<a href="https://niksongames.ru/tag/majestic/" class="tag-cloud-link tag-link-13 tag-link-position-6" style="font-size: 22pt;" aria-label="majestic (3 элемента)">majestic</a>
<a href="https://niksongames.ru/tag/majestic-rp/" class="tag-cloud-link tag-link-42 tag-link-position-7" style="font-size: 16.4pt;" aria-label="Majestic rp (2 элемента)">Majestic rp</a>
<a href="https://niksongames.ru/tag/roleplay/" class="tag-cloud-link tag-link-50 tag-link-position-8" style="font-size: 8pt;" aria-label="RolePlay (1 элемент)">RolePlay</a>
<a href="https://niksongames.ru/tag/rp/" class="tag-cloud-link tag-link-14 tag-link-position-9" style="font-size: 8pt;" aria-label="rp (1 элемент)">rp</a>
<a href="https://niksongames.ru/tag/yddy/" class="tag-cloud-link tag-link-5 tag-link-position-10" style="font-size: 8pt;" aria-label="YDDY (1 элемент)">YDDY</a>
<a href="https://niksongames.ru/tag/yddyrp/" class="tag-cloud-link tag-link-6 tag-link-position-11" style="font-size: 8pt;" aria-label="YDDY:RP (1 элемент)">YDDY:RP</a>
<a href="https://niksongames.ru/tag/egor-krid/" class="tag-cloud-link tag-link-49 tag-link-position-12" style="font-size: 8pt;" aria-label="Егор крид (1 элемент)">Егор крид</a>
<a href="https://niksongames.ru/tag/kinuli/" class="tag-cloud-link tag-link-12 tag-link-position-13" style="font-size: 8pt;" aria-label="КИНУЛИ (1 элемент)">КИНУЛИ</a>
<a href="https://niksongames.ru/tag/obnovlenie/" class="tag-cloud-link tag-link-47 tag-link-position-14" style="font-size: 8pt;" aria-label="обновление (1 элемент)">обновление</a>
<a href="https://niksongames.ru/tag/otvety/" class="tag-cloud-link tag-link-44 tag-link-position-15" style="font-size: 8pt;" aria-label="ответы (1 элемент)">ответы</a>
<a href="https://niksongames.ru/tag/prava/" class="tag-cloud-link tag-link-43 tag-link-position-16" style="font-size: 8pt;" aria-label="права (1 элемент)">права</a></p></div>
    
</aside><!-- #secondary -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/user/home.blade.php ENDPATH**/ ?>