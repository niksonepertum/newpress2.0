

<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
						<div class="check">
							<?php echo e(session('status')); ?>

						</div>
						<?php endif; ?>

<main id="main" class="site-main">

            <div class="breadcrumb" id="breadcrumbs"><span><span><a href="https://niksongames.ru/">Главная страница</a></span></span></div>
			
				<header class="page-header">
                    					<h1 class="page-title">Majestic RolePlay</h1>                    
                    <div class="child-categories"><ul><li><a href="https://niksongames.ru/majestic-roleplay/majestic-3-server/">Majestic 3 сервер</a></li><li><a href="https://niksongames.ru/majestic-roleplay/majestic-5-server/">Majestic 5 сервер</a></li></ul></div>					
					<div class="taxonomy-description"><p>Majestic RolePlay — это cервер, разработан на платформе RAGE Multiplayer (Рейдж Мультиплеер), который дает возможность отыгрывать выбранную роль в виртуальной вселенной, подчиняясь правилам реальной жизни. Станьте политиком, бандитом, бизнесменом, таксистом, рабочим на заводе, полицейским, в общем — кем угодно.</p>
<p>Что такое RolePlay? Направление игры, где каждый созданный игроком персонаж, отыгрывает заранее продуманную роль или сценарий. Индивидуальные и коллективные действия игроков создают ролевую ситуацию, участники которой отыгрывают собственных персонажей, руководствуясь характером своей роли в рамках игровых реалий.</p>
</div>				</header><!-- .page-header -->

                				
<div class="posts-container posts-container--two-columns">

    
<div id="post-229" class="post-card post-229 post type-post status-publish format-standard has-post-thumbnail  category-majestic-5-server category-majestic-roleplay tag-5-sejver tag-majestic tag-roleplay tag-egor-krid" itemscope="" itemtype="http://schema.org/BlogPosting">
    <div class="post-card__image"><a href="https://niksongames.ru/majestic-5-server-otkryte-v-1700/"><img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="Majestic 5 сервер открытье" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/11/vtnuxaxjaxa-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px"><div class="entry-meta"><span class="entry-category"><span itemprop="articleSection">Majestic 5 сервер</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></a></div><header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/majestic-5-server-otkryte-v-1700/">Majestic 5 сервер открытье в 17:00</a></span></div></header><div class="post-card__content" itemprop="articleBody">Этот день настал! Сегодня 5 ноября Majestic 5 сервер и главный вопрос зачем? Онлайн</div>
    	<meta itemprop="author" content="Nikson">
	<meta itemscope="" itemprop="mainEntityOfPage" itemtype="https://schema.org/WebPage" itemid="https://niksongames.ru/majestic-5-server-otkryte-v-1700/" content="Majestic 5 сервер открытье в 17:00">
	<meta itemprop="dateModified" content="2021-11-07">
	<meta itemprop="datePublished" content="2021-11-05T12:20:50+03:00">
    <div itemprop="publisher" itemscope="" itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope="" itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>    
</div>
<div id="post-206" class="post-card post-206 post type-post status-publish format-standard has-post-thumbnail  category-majestic-roleplay tag-majestic-rp tag-obnovlenie" itemscope="" itemtype="http://schema.org/BlogPosting">
    <div class="post-card__image"><a href="https://niksongames.ru/obnovlenie-na-majestic-rp/"><img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-330x140.png" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="обновление на Majestic rp наконец-то вышло" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-330x140.png 330w, https://niksongames.ru/wp-content/uploads/2021/11/unknownauto-770x330.png 770w" sizes="(max-width: 330px) 100vw, 330px"><div class="entry-meta"><span class="entry-category"><span itemprop="articleSection">Majestic RolePlay</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></a></div><header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/obnovlenie-na-majestic-rp/">обновление на Majestic rp наконец-то вышло</a></span></div></header><div class="post-card__content" itemprop="articleBody">Друзья рад вам сообщить, что самое долгожданное обновление на Majestic rp наконец-то вышло! Сегодня</div>
    	<meta itemprop="author" content="Nikson">
	<meta itemscope="" itemprop="mainEntityOfPage" itemtype="https://schema.org/WebPage" itemid="https://niksongames.ru/obnovlenie-na-majestic-rp/" content="обновление на Majestic rp наконец-то вышло">
	<meta itemprop="dateModified" content="2021-11-02">
	<meta itemprop="datePublished" content="2021-11-01T11:07:45+03:00">
    <div itemprop="publisher" itemscope="" itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope="" itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>    
</div>
<div id="post-43" class="post-card post-43 post type-post status-publish format-standard has-post-thumbnail  category-majestic-3-server category-majestic-roleplay tag-majestic tag-rp tag-kinuli" itemscope="" itemtype="http://schema.org/BlogPosting">
    <div class="post-card__image"><a href="https://niksongames.ru/majestic-rp-3-server/"><img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="КИНУЛИ НА БАБКИ majestic rp 3 сервер" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/08/20210815221928_1-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px"><div class="entry-meta"><span class="entry-category"><span itemprop="articleSection">Majestic 3 сервер</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 6</span></span></div></a></div><header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/majestic-rp-3-server/">КИНУЛИ НА БАБКИ? Маджестик говно!</a></span></div></header><div class="post-card__content" itemprop="articleBody">Сегодня я расскажу как меня КИНУЛИ НА БАБКИ majestic rp 3 сервер, думаю будет</div>
    	<meta itemprop="author" content="Nikson">
	<meta itemscope="" itemprop="mainEntityOfPage" itemtype="https://schema.org/WebPage" itemid="https://niksongames.ru/majestic-rp-3-server/" content="КИНУЛИ НА БАБКИ? Маджестик говно!">
	<meta itemprop="dateModified" content="2021-11-07">
	<meta itemprop="datePublished" content="2021-08-18T12:46:03+03:00">
    <div itemprop="publisher" itemscope="" itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope="" itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>    
</div>
<div id="post-40" class="post-card post-40 post type-post status-publish format-standard has-post-thumbnail  category-majestic-roleplay tag-majestic tag-majestic-rp tag-otvety tag-prava" itemscope="" itemtype="http://schema.org/BlogPosting">
    <div class="post-card__image"><a href="https://niksongames.ru/kak-sdat-na-prava-na-majestic-rp/"><img width="330" height="140" src="https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-330x140.jpg" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="Как сдать на права на Majestic rp" loading="lazy" itemprop="image" srcset="https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-330x140.jpg 330w, https://niksongames.ru/wp-content/uploads/2021/08/e1me4a-hxwi-770x330.jpg 770w" sizes="(max-width: 330px) 100vw, 330px"><div class="entry-meta"><span class="entry-category"><span itemprop="articleSection">Majestic RolePlay</span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></a></div><header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="https://niksongames.ru/kak-sdat-na-prava-na-majestic-rp/">Как сдать на права на Majestic rp? Правильные ответы</a></span></div></header><div class="post-card__content" itemprop="articleBody">Многие новички на сереве задаются вопросом Как сдать на права на Majestic rp? Я</div>
    	<meta itemprop="author" content="Nikson">
	<meta itemscope="" itemprop="mainEntityOfPage" itemtype="https://schema.org/WebPage" itemid="https://niksongames.ru/kak-sdat-na-prava-na-majestic-rp/" content="Как сдать на права на Majestic rp? Правильные ответы">
	<meta itemprop="dateModified" content="2021-10-14">
	<meta itemprop="datePublished" content="2021-08-16T17:51:35+03:00">
    <div itemprop="publisher" itemscope="" itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope="" itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>    
</div>
</div>                
								
								
			
		</main><!-- #main -->

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.castom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/posts/arhive.blade.php ENDPATH**/ ?>