

<?php $__env->startSection('content'); ?>

<?php if(Auth::check() && Auth::user()->role == 4): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Добавить страницу</div>

                <div class="card-body">




  <form action="<?php echo e(Route('post.store')); ?>" enctype="multipart/form-data" method="post">
    <?php echo e(csrf_field()); ?>

	
  
  
  <div class="mb-3">
  <label for="create_title" class="form-label">Заголовок</label>
  <input type="text" class="form-control" id="create_title" name="title" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
  <label for="lable-excerpt" class="form-label">Описание</label>
  <textarea id="lable-excerpt" name="excerpt"></textarea>
  <small>До 128 симвалов с пробелами</small>
  <script>CKEDITOR.replace( 'excerpt' );</script>
  </div>
  
  <div class="mb-3">
  <label for="lable-content" class="form-label">Статья</label>
  <textarea id="lable-content" name="content" class="form-control"></textarea>
  <script>CKEDITOR.replace( 'content' );</script>
  </div>


                    <br />


                    <div class="mb-3">
                    <label for="create_photo" class="form-label">Добавить фото</label>
                    <input type="file" class="form-control" id="create_photo" name="img" aria-describedby="emailHelp">
                    </div>


                    

                      <input type="submit" value="Добавить" class="btn btn-sm btn-outline-secondary">

                </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php else: ?>
<div class="alert alert-danger" role="alert">
  Доступ к этой страницы закрыт
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/posts/create.blade.php ENDPATH**/ ?>