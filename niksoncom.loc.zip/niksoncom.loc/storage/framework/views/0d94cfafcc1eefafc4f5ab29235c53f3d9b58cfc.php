

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($phone->title); ?></div>

                <div class="card-body">

                <p><?php echo e($phone->description); ?></p>


                  <form action="<?php echo e(Route('page.store')); ?>"  method="post">
                    <?php echo e(csrf_field()); ?>

                  <div class="mb-3">
                  <label for="create_title" class="form-label">Ваше имя</label>
                  <input type="text" class="form-control" id="create_title" name="title" aria-describedby="emailHelp">
                  </div>

                  <div class="mb-3">
                  <label for="create_title" class="form-label">Ваш Email</label>
                  <input type="text" class="form-control" id="create_title" name="title" aria-describedby="emailHelp">
                  </div>

                  <div class="mb-3">
                  <label for="create_title" class="form-label">Тема письма</label>
                  <input type="text" class="form-control" id="create_title" name="thems" aria-describedby="emailHelp">
                  </div>

                  <div class="mb-3">
                  <label for="lable-content" class="form-label">Сообщение</label>
                  <textarea id="lable-content" name="content" class="form-control"></textarea>
                  <small>Нажав "отправить письмо" вы соглашаетесь на <a href="<?php echo e($phone->url); ?>">обработку персональных данных</a></small>
                  </div>

                     <input type="submit" value="Отправить письмо" class="btn btn-sm btn-outline-secondary">

                                </form>

                    <br />  <br />



                    <?php if( Auth::user()->role == 4): ?>

                    <div class="btn-group">
                      <a href="#" class="btn btn-sm btn-outline-secondary">Редактировать</a>
                      <a href="#" class="btn btn-sm btn-outline-secondary">Удалить</a>

                    </div>

                      <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/page/phone.blade.php ENDPATH**/ ?>