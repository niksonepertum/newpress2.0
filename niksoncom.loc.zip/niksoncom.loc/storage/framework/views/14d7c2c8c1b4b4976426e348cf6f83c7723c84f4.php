


<?php $__env->startSection('content'); ?>
    
                
					

            
            
				<div class="entry-image entry-image--big">
                <img width="2560" height="1440" src="<?php echo e($page->getPosts()); ?>" class="attachment-full size-full wp-post-image" alt="" loading="lazy" itemprop="image" 
				srcset="<?php echo e($page->getPosts()); ?> 2560w, <?php echo e($page->getPosts()); ?> 300w, <?php echo e($page->getPosts()); ?> 1024w, <?php echo e($page->getPosts()); ?> 768w, <?php echo e($page->getPosts()); ?> 1536w, <?php echo e($page->getPosts()); ?> 2048w, <?php echo e($page->getPosts()); ?> 
				250w, <?php echo e($page->getPosts()); ?> 550w, <?php echo e($page->getPosts()); ?> 800w, <?php echo e($page->getPosts()); ?> 320w, <?php echo e($page->getPosts()); ?> 533w, <?php echo e($page->getPosts()); ?> 889w" sizes="(max-width: 2560px) 100vw, 2560px">        
                <div class="entry-image__title">
                <div class="breadcrumb" id="breadcrumbs"><span><span><a href="https://niksongames.ru/">Главная страница</a></span></span></div>
                <h1 itemprop="headline"><?php echo e($page->title); ?></h1>
                </div></div>
                
<div id="primary" class="content-area">
		
<main id="main" class="site-main">
<article id="post-139" class="post-139 page type-page status-publish has-post-thumbnail ">
<div class="entry-content" itemprop="articleBody">

      <?php echo $page->content; ?>      
           
</div>
<!-- toc empty -->    
<?php if( Auth::user()->role == 4): ?>



                    
<div class="child-categories">
<ul>

                      <li><a  class="child-categories" href="<?php echo e(Route('page.edit', $page->id)); ?>">Редактировать</a></li>
                      <li><a href="#" class="child-categories">Удалить</a></li>

</ul>
                    </div>
                      <?php endif; ?>

</div><!-- .entry-content -->
</article><!-- #post-## -->








<meta itemscope="" itemprop="mainEntityOfPage" itemtype="https://schema.org/WebPage" itemid="https://niksongames.ru/karta-sajta/" content="Карта сайта">
<meta itemprop="dateModified" content="2021-11-19">
<meta itemprop="datePublished" content="2021-11-19T19:56:32+03:00">
<meta itemprop="author" content="Nikson">
<div itemprop="publisher" itemscope="" itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope="" itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
		</main>

  
	</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/page/show.blade.php ENDPATH**/ ?>