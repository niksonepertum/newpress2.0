

<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
						<div class="check">
							<?php echo e(session('status')); ?>

						</div>
						<?php endif; ?>

<main id="main" class="site-main">

            <div class="breadcrumb" id="breadcrumbs"><span><span><a href="https://niksongames.ru/">Главная страница</a></span></span></div>
			
				<header class="page-header">
                    					<h1 class="page-title"><?php echo e($category->title); ?></h1>                    
                    <div class="child-categories"><ul><li><a href="https://niksongames.ru/majestic-roleplay/majestic-3-server/">Majestic 3 сервер</a></li><li><a href="https://niksongames.ru/majestic-roleplay/majestic-5-server/">Majestic 5 сервер</a></li></ul></div>					
					<div class="taxonomy-description"><p><?php echo $category->description; ?></p>
</div>				</header><!-- .page-header -->

                				
<div class="posts-container posts-container--two-columns">

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="post-229" class="post-card post-229 post type-post status-publish format-standard has-post-thumbnail  category-majestic-5-server category-majestic-roleplay tag-5-sejver tag-majestic tag-roleplay tag-egor-krid" itemscope="" itemtype="http://schema.org/BlogPosting">
    <div class="post-card__image">
	<a href="https://niksongames.ru/majestic-5-server-otkryte-v-1700/">
	<img width="330" height="140" src="<?php echo e($post->getPosts()); ?>" class="attachment-thumb-wide size-thumb-wide wp-post-image" alt="Majestic 5 сервер открытье" loading="lazy" itemprop="image" srcset="<?php echo e($post->getPosts()); ?> 330w, <?php echo e($post->getPosts()); ?> 770w" sizes="(max-width: 330px) 100vw, 330px">
	<div class="entry-meta"></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></a></div><header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="<?php echo e(route('post.show',  $post->slug)); ?>"><?php echo e($post->title); ?></a></span></div></header><div class="post-card__content" itemprop="articleBody"><?php echo $post->excerpt; ?></div>
    	<meta itemprop="author" content="Nikson">
	<meta itemscope="" itemprop="mainEntityOfPage" itemtype="https://schema.org/WebPage" itemid="https://niksongames.ru/majestic-5-server-otkryte-v-1700/" content="Majestic 5 сервер открытье в 17:00">
	<meta itemprop="dateModified" content="2021-11-07">
	<meta itemprop="datePublished" content="2021-11-05T12:20:50+03:00">
    <div itemprop="publisher" itemscope="" itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope="" itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>    
</div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>                
								
								
			
		</main><!-- #main -->

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.castom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/Category/show.blade.php ENDPATH**/ ?>