

<?php $__env->startSection('content'); ?>

<?php if(Auth::check() && Auth::user()->role == 4): ?>
<?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

                

               
<main id="main" class="site-main">

            
            <div class="breadcrumb" id="breadcrumbs"><span><span><a href="https://niksongames.ru/">Главная страница</a></span></span></div>
            
<article id="post-250" class="post-250 page type-page status-publish ">

    
                    <header class="entry-header">
                                <h1 class="entry-title" itemprop="headline">Редактировать статью</h1>                            </header><!-- .entry-header -->
        
        
                    <div class="page-separator"></div>
        
    
     <form action="<?php echo e(Route('post.update', $post->id)); ?>" enctype="multipart/form-data" method="post">
    <?php echo e(csrf_field()); ?>

  <div style="width:1090px; padding:10px 0;">
  <label for="create_title" class="form-label">Заголовок</label>
  <input type="text" class="search-form__text" id="create_title" name="title" placeholder="" value="<?php echo e($post->title); ?>" aria-describedby="emailHelp">
  
  <small> Заголовок статьи лучше не менять <strong>Изменяется и адресс страницы </strong></small>
  </div>
  <select class="search-form__text" id="inlineFormCustomSelect" name="category_id">

                     <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($post->category_id == $category->id): ?>
                     <option value="<?php echo e($category->id); ?>" selected="selected"><?php echo e($category->title); ?></option>
				     <?php else: ?>
					 <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
				     <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>


  <div style="width:1090px; padding:10px 0;">
  <label for="lable-excerpt" class="form-label">Описание</label>
  <textarea id="excerpt" name="excerpt" cols="45" rows="8" ><?php echo e($post->excerpt); ?></textarea>
  <small>До 128 симвалов с пробелами</small>
  <script>CKEDITOR.replace( 'excerpt' );</script>
  </div>
  
  <div style="width:1090px; padding:10px 0;">
  <label for="lable-content" class="form-label">Статья</label>
  <textarea id="excerpt1" name="content" cols="45" rows="8"  required="required"><?php echo e($post->content); ?></textarea>
  <script>CKEDITOR.replace( 'excerpt1' );</script>
  </div>
  


                   <label for="iFormCustomSelect" class="form-label">Статус статьи</label>
  <select class="search-form__text" id="iFormCustomSelect" name="is_public">
                   <option value="0">Черновик</option>
                    <?php if($post->is_public == 1): ?>
                     <option value="<?php echo e($post->is_public); ?>" selected="selected">Опубликовано</option>
				     <?php else: ?>
					 <option value="2">Скрытый</option>
				     <?php endif; ?>
                     
                     <option value="<?php echo e($post->is_public); ?>">Опубликованый</option>
				     
                     
                  </select>


                    
                    <label for="edit_photo" class="form-label">Текущее фото</label>
                    <img  alt="<?php echo e($post->title); ?>" style="height: 60px; width: 100px; display: block;" src="<?php echo e($post->getPosts()); ?>" id="edit_photo">
                    <label for="create_photo" class="form-label">Изменить фото</label>
                    <input type="file" class="form-control" id="create_photo" name="img" aria-describedby="emailHelp">
                    

                    <input type="hidden" name="_method" value="put">
                    <input type="hidden"  name="user_id" value="<?php echo e($post->user_id); ?>">


                    <input type="submit" value="Сохранить" class="btn btn-sm btn-outline-secondary">

                </form>

</article>
		</main>



 
                

<?php else: ?>
<div class="alert alert-danger" role="alert">
  Доступ к этой страницы закрыт
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.castom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/post/edit.blade.php ENDPATH**/ ?>