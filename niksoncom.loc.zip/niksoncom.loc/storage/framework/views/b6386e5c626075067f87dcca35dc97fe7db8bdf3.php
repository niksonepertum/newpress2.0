

<?php $__env->startSection('content'); ?>

<div class="info"><p>Функционал в разработке</p></div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.blog-feed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/user/feed.blade.php ENDPATH**/ ?>