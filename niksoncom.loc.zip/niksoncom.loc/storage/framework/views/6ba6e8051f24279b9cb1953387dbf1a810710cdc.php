

<?php $__env->startSection('content'); ?>

<main id="main" class="site-main">

            
            <div class="breadcrumb" id="breadcrumbs"><span><span><a href="https://niksongames.ru/">Главная страница</a></span></span></div>
            
<article id="post-250" class="post-250 page type-page status-publish ">

    
                    <header class="entry-header">
                                <h1 class="entry-title" itemprop="headline"><?php echo e($you->title); ?></h1>                            </header><!-- .entry-header -->
        
        
                    <div class="page-separator"></div>
					
					<div class="taxonomy-description"><?php echo $you->description; ?></div>
        
    
 

              

<!-- toc empty -->    </div><!-- .entry-content -->
</article><!-- #post-## -->








<meta itemscope="" itemprop="mainEntityOfPage" itemtype="https://schema.org/WebPage" itemid="https://niksongames.ru/karta-sajta/" content="Карта сайта">
<meta itemprop="dateModified" content="2021-11-19">
<meta itemprop="datePublished" content="2021-11-19T19:56:32+03:00">
<meta itemprop="author" content="Nikson">
<div itemprop="publisher" itemscope="" itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope="" itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
		</main>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.castom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/donat/thank.blade.php ENDPATH**/ ?>