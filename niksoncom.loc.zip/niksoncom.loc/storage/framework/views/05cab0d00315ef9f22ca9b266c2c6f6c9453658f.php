<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
						<div class="alert alert-success">
							<?php echo e(session('status')); ?>

						</div>
						<?php endif; ?>
<div class="row">



  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="col-md-4">
          <div class="card mb-4 box-shadow">
            <img class="card-img-top" data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=[[$post->title]]" alt="<?php echo e($post->title); ?>" style="height: 225px; width: 100%; display: block;" src="<?php echo e($post->getPosts()); ?>" data-holder-rendered="true">
            <div class="card-body">
              <h2><?php echo e($post->title); ?></h2>
              <p class="card-text"><?php echo e($post->excerpt); ?></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <a href="<?php echo e($post->slug); ?>" class="btn btn-sm btn-outline-secondary">Читать</a>

                </div>
                <small class="text-muted"><?php echo e(Date::parse($post->created_at)->format('j F Y г.')); ?></small>
              </div>
            </div>
          </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



      </div>

        <?php echo e($posts->links("paginate")); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/posts/all.blade.php ENDPATH**/ ?>