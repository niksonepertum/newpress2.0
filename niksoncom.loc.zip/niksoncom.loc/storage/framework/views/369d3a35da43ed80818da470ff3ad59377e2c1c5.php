

<?php $__env->startSection('content'); ?>

<?php if(Auth::check() && Auth::user()->role == 4): ?>
<?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Редактировать статью</div>

                <div class="card-body">




  <form action="<?php echo e(Route('post.update', $post->id)); ?>" enctype="multipart/form-data" method="post">
    <?php echo e(csrf_field()); ?>

  <div class="mb-3">
  <label for="create_title" class="form-label">Заголовок</label>
  <input type="text" class="form-control" id="create_title" name="title" placeholder="" value="<?php echo e($post->title); ?>" aria-describedby="emailHelp">
  
  <small> Заголовок статьи лучше не менять <strong>Изменяется и адресс страницы </strong></small>
  </div>




  <div class="mb-3">
  <label for="lable-excerpt" class="form-label">Описание</label>
  <textarea id="lable-excerpt" name="excerpt" class="form-control"><?php echo e($post->excerpt); ?></textarea>
  <small>До 128 симвалов с пробелами</small>
  <script>CKEDITOR.replace( 'excerpt' );</script>
  </div>
  <div class="mb-3">
  <label for="lable-content" class="form-label">Статья</label>
  <textarea id="lable-content" name="content" class="form-control"><?php echo e($post->content); ?></textarea>
  <script>CKEDITOR.replace( 'content' );</script>
  </div>


                    <br />


                    <div class="mb-3">
                    <label for="edit_photo" class="form-label">Текущее фото</label>
                    <img  alt="<?php echo e($post->title); ?>" style="height: 60px; width: 100px; display: block;" src="<?php echo e($post->getPosts()); ?>" id="edit_photo">
                    <label for="create_photo" class="form-label">Изменить фото</label>
                    <input type="file" class="form-control" id="create_photo" name="img" aria-describedby="emailHelp">
                    </div>

                    <input type="hidden" name="_method" value="put">
                    <input type="hidden"  name="user_id" value="<?php echo e($post->user_id); ?>">


                    <input type="submit" value="Сохранить" class="btn btn-sm btn-outline-secondary">

                </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php else: ?>
<div class="alert alert-danger" role="alert">
  Доступ к этой страницы закрыт
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/posts/edit.blade.php ENDPATH**/ ?>