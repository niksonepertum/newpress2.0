<?php if(config('app.url') == config('app.url')): ?>
	

	
gg


	<!--<img src="<?php echo e(asset('images/eac8850e.png')); ?>" width="210" height="52" alt="NiksonGames">-->



<?php else: ?>

<a href="/">111</a>
	

<!--<a href="/"><img src="<?php echo e(asset('images/eac8850e.png')); ?>" width="210" height="52" alt="NiksonGames"></a>-->	

<?php endif; ?> <?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/layouts/include/site-logotype.blade.php ENDPATH**/ ?>