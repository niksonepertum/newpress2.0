<div id="search-2" class="widget widget_search">
<form role="search" method="get" id="searchform_993" action="https://niksongames.ru/" class="search-form">
    <label class="screen-reader-text" for="s_993">Поиск: </label>
    <input type="text" value="" name="s" id="s_993" class="search-form__text">
    <button type="submit" id="searchsubmit_993" class="search-form__submit"></button>
</form></div><div id="block-3" class="widget widget_block">
<ul class="wp-block-social-links is-style-pill-shape"></ul>

</div>

<div id="categories-2" class="widget widget_categories"><div class="widget-header">Рубрики</div>
			<ul>
					<li class="cat-item cat-item-52"><a href="https://niksongames.ru/majestic-roleplay/majestic-3-server/" title="Если вам не нужен красивый статик на сервере и вы цените стабильность majestic 3 сервер - это ваш выбор А стартовать лучше с нашей семьёй на сервере.">Majestic 3 сервер</a>
</li>
	<li class="cat-item cat-item-51"><a href="https://niksongames.ru/majestic-roleplay/majestic-5-server/" title="Хотите зайти на Majestic? Поздравляю вас сейчас самое лучшее время majestic 5 сервер открыт! Новая жизнь новый штат. Новые друзья.">Majestic 5 сервер</a>
</li>
	<li class="cat-item cat-item-7"><a href="https://niksongames.ru/majestic-roleplay/" title="Majestic RolePlay - это cервер, разработан на платформе RAGE Multiplayer (Рейдж Мультиплеер), который дает возможность отыгрывать выбранную роль в виртуальной вселенной, подчиняясь правилам реальной жизни. Станьте политиком, бандитом, бизнесменом, таксистом, рабочим на заводе, полицейским, в общем - кем угодно.

Что такое RolePlay? Направление игры, где каждый созданный игроком персонаж, отыгрывает заранее продуманную роль или сценарий. Индивидуальные и коллективные действия игроков создают ролевую ситуацию, участники которой отыгрывают собственных персонажей, руководствуясь характером своей роли в рамках игровых реалий.">Majestic RolePlay</a>
</li>
	<li class="cat-item cat-item-40"><a href="https://niksongames.ru/skachat-igru-besplatno-bez-interneta/">Наши релизы</a>
</li>
	<li class="cat-item cat-item-10"><a href="https://niksongames.ru/poslednie-novosti-kompyuternyh-igr/">Новости</a>
</li>
	<li class="cat-item cat-item-1"><a href="https://niksongames.ru/obzory-video-igr/">Обзоры видео игр</a>
</li>
			</ul>

			</div>
			
			<div id="archives-2" class="widget widget_archive"><div class="widget-header">Архивы</div>
			<ul>
					<li><a href='https://niksongames.ru/2021/11/'>Ноябрь 2021</a></li>
	<li><a href='https://niksongames.ru/2021/10/'>Октябрь 2021</a></li>
	<li><a href='https://niksongames.ru/2021/09/'>Сентябрь 2021</a></li>
	<li><a href='https://niksongames.ru/2021/08/'>Август 2021</a></li>
	<li><a href='https://niksongames.ru/2020/02/'>Февраль 2020</a></li>
			</ul>

			</div>
			
			<div id="block-2" class="widget widget_block widget_tag_cloud"><p class="wp-block-tag-cloud"><a href="https://niksongames.ru/tag/5-sejver/" class="tag-cloud-link tag-link-48 tag-link-position-1" style="font-size: 8pt;" aria-label="5 Сейвер (1 элемент)">5 Сейвер</a>
<a href="https://niksongames.ru/tag/ats/" class="tag-cloud-link tag-link-55 tag-link-position-2" style="font-size: 8pt;" aria-label="ATS (1 элемент)">ATS</a>
<a href="https://niksongames.ru/tag/dlc/" class="tag-cloud-link tag-link-56 tag-link-position-3" style="font-size: 8pt;" aria-label="DLC (1 элемент)">DLC</a>
<a href="https://niksongames.ru/tag/gta-5/" class="tag-cloud-link tag-link-3 tag-link-position-4" style="font-size: 8pt;" aria-label="GTA 5 (1 элемент)">GTA 5</a>
<a href="https://niksongames.ru/tag/gta-5-rp/" class="tag-cloud-link tag-link-4 tag-link-position-5" style="font-size: 8pt;" aria-label="GTA 5 RP (1 элемент)">GTA 5 RP</a>
<a href="https://niksongames.ru/tag/majestic/" class="tag-cloud-link tag-link-13 tag-link-position-6" style="font-size: 22pt;" aria-label="majestic (3 элемента)">majestic</a>
<a href="https://niksongames.ru/tag/majestic-rp/" class="tag-cloud-link tag-link-42 tag-link-position-7" style="font-size: 16.4pt;" aria-label="Majestic rp (2 элемента)">Majestic rp</a>
<a href="https://niksongames.ru/tag/roleplay/" class="tag-cloud-link tag-link-50 tag-link-position-8" style="font-size: 8pt;" aria-label="RolePlay (1 элемент)">RolePlay</a>
<a href="https://niksongames.ru/tag/rp/" class="tag-cloud-link tag-link-14 tag-link-position-9" style="font-size: 8pt;" aria-label="rp (1 элемент)">rp</a>
<a href="https://niksongames.ru/tag/yddy/" class="tag-cloud-link tag-link-5 tag-link-position-10" style="font-size: 8pt;" aria-label="YDDY (1 элемент)">YDDY</a>
<a href="https://niksongames.ru/tag/yddyrp/" class="tag-cloud-link tag-link-6 tag-link-position-11" style="font-size: 8pt;" aria-label="YDDY:RP (1 элемент)">YDDY:RP</a>
<a href="https://niksongames.ru/tag/egor-krid/" class="tag-cloud-link tag-link-49 tag-link-position-12" style="font-size: 8pt;" aria-label="Егор крид (1 элемент)">Егор крид</a>
<a href="https://niksongames.ru/tag/kinuli/" class="tag-cloud-link tag-link-12 tag-link-position-13" style="font-size: 8pt;" aria-label="КИНУЛИ (1 элемент)">КИНУЛИ</a>
<a href="https://niksongames.ru/tag/obnovlenie/" class="tag-cloud-link tag-link-47 tag-link-position-14" style="font-size: 8pt;" aria-label="обновление (1 элемент)">обновление</a>
<a href="https://niksongames.ru/tag/otvety/" class="tag-cloud-link tag-link-44 tag-link-position-15" style="font-size: 8pt;" aria-label="ответы (1 элемент)">ответы</a>
<a href="https://niksongames.ru/tag/prava/" class="tag-cloud-link tag-link-43 tag-link-position-16" style="font-size: 8pt;" aria-label="права (1 элемент)">права</a></p></div><?php /**PATH C:\OpenServer\domains\niksoncom.loc\resources\views/layouts/include/aside.blade.php ENDPATH**/ ?>