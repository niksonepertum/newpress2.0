<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [App\Http\Controllers\PostController::class, 'index'])->name('main');

Route::get('/{slug}', [App\Http\Controllers\PostController::class, 'show'])->name('pageshow');
Route::resources(['post' => App\Http\Controllers\PostController::class]);

Route::get('/squad/karta-sajta', [App\Http\Controllers\СategoryController::class, 'index'])->name('karta-sajta');
Route::get('/category/{slug}', [App\Http\Controllers\СategoryController::class, 'show'])->name('categories');
Route::resources(['category' => App\Http\Controllers\СategoryController::class]);

Route::get('/pages/phone', [App\Http\Controllers\EmailController::class, 'index'])->name('phone');
Route::get('/squad/donate', [App\Http\Controllers\DonateController::class, 'donate'])->name('donate');
Route::get('/squad/donate/thank', [App\Http\Controllers\DonateController::class, 'thank'])->name('thank');
Route::get('/pages/{slug}', [App\Http\Controllers\PageController::class, 'show'])->name('show');

Route::resources(['page' => App\Http\Controllers\PageController::class]);




Route::group(['prefix' => 'auth'], function() {

  Auth::routes();


  Route::get('/rules', [App\Http\Controllers\PageController::class, 'rule'])->name('rules');
});

Route::get('/user/{id}', [App\Http\Controllers\HomeController::class, 'show'])->name('home');
Route::resources(['user' => App\Http\Controllers\HomeController::class]);
Route::get('/home/feed', [App\Http\Controllers\feedController::class, 'index'])->name('feed');
