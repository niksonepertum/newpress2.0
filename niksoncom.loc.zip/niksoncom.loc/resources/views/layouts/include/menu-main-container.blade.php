<ul id="top_menu" class="menu">
				
<li id="menu-item-256" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-256"><a href="{{ route('karta-sajta') }}">Карта сайта</a></li>
<li id="menu-item-257" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-257"><a href="http://niksoncom.loc/pages/abaut">Автор</a></li>
<li id="menu-item-79" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-79"><a href="https://niksongames.ru/kanal-youtube-prohozhdenie-igr/">Видео</a></li>
 <!-- Authentication Links -->
                        @guest
                            @if (Route::has('login'))
                                <li id="menu-item-79" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-79">
                                    <a  href="{{ route('login') }}">{{ __('Войти') }}</a>
                                </li>
                            @endif

                            
                        @else
							
						@if( Auth::user()->role == 4)
<li id="menu-item-257" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-257"><a href="#">Добавить</a>
<ul class="sub-menu" style="display: none;">
	<li id="menu-item-277" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-277"><a href="{{ Route('post.create') }}">Статью</a></li>
	<li id="menu-item-278" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-278"><a href="{{ Route('page.create') }}">Страницу</a></li>
	<li id="menu-item-278" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-278"><a href="#">Категорию</a></li>
	<li id="menu-item-278" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-278"><a href="#">Пользователя</a></li>
</ul>
</li>
@endif
						<li id="menu-item-257" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-257"><a href="#">{{ Auth::user()->name }}</a>
<ul class="sub-menu" style="display: none;">
	<li id="menu-item-277" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-277"><a href="/user/{{ Auth::user()->id }}">Профиль</a></li>
	<li id="menu-item-278" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-278"><a  href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Выход') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                </div>
                            </li>
</ul>
						
						
                        @endguest
						


</ul>