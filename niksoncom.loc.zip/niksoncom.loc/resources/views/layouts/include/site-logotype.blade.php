@if(config('app.url') == config('app.url'))
	

	
gg


	<!--<img src="{{ asset('images/eac8850e.png') }}" width="210" height="52" alt="NiksonGames">-->



@else

<a href="/">111</a>
	

<!--<a href="{{ url('/') }}"><img src="{{ asset('images/eac8850e.png') }}" width="210" height="52" alt="NiksonGames"></a>-->	

@endif 