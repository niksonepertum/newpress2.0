<!DOCTYPE html>
<html lang="ru-RU">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />

	<!-- This site is optimized with the Yoast SEO plugin v17.6 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>{{$page->name }} | {{ config('meta.motto', 'Laravel' ) }}</title>
	<meta name="description" content="Новостиобзоры игровой индустрии" />
	<link rel="canonical" href="https://niksongames.ru/" />
	<meta property="og:locale" content="ru_RU" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="NiksonGames" />
	<meta property="og:description" content="Новости\обзоры игровой индустрии" />
	<meta property="og:url" content="https://niksongames.ru/" />
	<meta property="og:site_name" content="NiksonGames" />
	<meta name="twitter:card" content="summary_large_image" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://niksongames.ru/#website","url":"https://niksongames.ru/","name":"NiksonGames","description":"\u041d\u043e\u0432\u043e\u0441\u0442\u0438\\\u043e\u0431\u0437\u043e\u0440\u044b \u0438\u0433\u0440\u043e\u0432\u043e\u0439 \u0438\u043d\u0434\u0443\u0441\u0442\u0440\u0438\u0438","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://niksongames.ru/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"ru-RU"},{"@type":"CollectionPage","@id":"https://niksongames.ru/#webpage","url":"https://niksongames.ru/","name":"NiksonGames - \u041d\u043e\u0432\u043e\u0441\u0442\u0438\\\u043e\u0431\u0437\u043e\u0440\u044b \u0438\u0433\u0440\u043e\u0432\u043e\u0439 \u0438\u043d\u0434\u0443\u0441\u0442\u0440\u0438\u0438","isPartOf":{"@id":"https://niksongames.ru/#website"},"description":"\u041d\u043e\u0432\u043e\u0441\u0442\u0438\\\u043e\u0431\u0437\u043e\u0440\u044b \u0438\u0433\u0440\u043e\u0432\u043e\u0439 \u0438\u043d\u0434\u0443\u0441\u0442\u0440\u0438\u0438","breadcrumb":{"@id":"https://niksongames.ru/#breadcrumb"},"inLanguage":"ru-RU","potentialAction":[{"@type":"ReadAction","target":["https://niksongames.ru/"]}]},{"@type":"BreadcrumbList","@id":"https://niksongames.ru/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"\u0413\u043b\u0430\u0432\u043d\u0430\u044f \u0441\u0442\u0440\u0430\u043d\u0438\u0446\u0430"}]}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/niksongames.ru\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	
<link rel='stylesheet' id='google-fonts-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A400%2C400i%2C700&#038;subset=cyrillic&#038;display=swap&#038;ver=5.8.2'  media='all' />
<link rel='stylesheet' id='root-style-css' href="{{ asset('css/style.min.css') }}" media='all'>
<link rel='stylesheet' id='root-style-css' href="{{ asset('css/nikson.min.css') }}" media='all'>

                
<script  src='https://niksongames.ru/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script  src='https://niksongames.ru/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>


<style>.site-logotype {max-width:1000px}.site-logotype img {max-height:269px}@media (max-width: 991px) {.mob-search{display:block;margin-bottom:25px} }.scrolltop {background-color:#cccccc}.scrolltop:after {color:#ffffff}.scrolltop {width:50px}.scrolltop {height:50px}.scrolltop:after {content:"\f102"}.entry-image:not(.entry-image--big) {margin-left:-20px}@media (min-width: 1200px) {.entry-image:not(.entry-image--big) {margin-left:-40px} }.b-related .post-card__image, .b-related .post-card__image img, .b-related .post-card__image .entry-meta, .b-related .thumb-wide {border-radius:6px}body {font-family:"Roboto" ,"Helvetica Neue", Helvetica, Arial, sans-serif}@media (min-width: 576px) {body {font-size:16px} }@media (min-width: 576px) {body {line-height:1.5} }.site-title, .site-title a {font-family:"Roboto" ,"Helvetica Neue", Helvetica, Arial, sans-serif}@media (min-width: 576px) {.site-title, .site-title a {font-size:28px} }@media (min-width: 576px) {.site-title, .site-title a {line-height:1.1} }.site-description {font-family:"Roboto" ,"Helvetica Neue", Helvetica, Arial, sans-serif}@media (min-width: 576px) {.site-description {font-size:16px} }@media (min-width: 576px) {.site-description {line-height:1.5} }.main-navigation ul li a, .main-navigation ul li .removed-link, .footer-navigation ul li a, .footer-navigation ul li .removed-link{font-family:"Roboto" ,"Helvetica Neue", Helvetica, Arial, sans-serif}@media (min-width: 576px) {.main-navigation ul li a, .main-navigation ul li .removed-link, .footer-navigation ul li a, .footer-navigation ul li .removed-link {font-size: 16px} }@media (min-width: 576px) {.main-navigation ul li a, .main-navigation ul li .removed-link, .footer-navigation ul li a, .footer-navigation ul li .removed-link {line-height:1.5} }.h1, h1:not(.site-title) {font-weight:bold;}.h2, h2 {font-weight:bold;}.h3, h3 {font-weight:bold;}.h4, h4 {font-weight:bold;}.h5, h5 {font-weight:bold;}.h6, h6 {font-weight:bold;}.mob-hamburger span, .card-slider__category, .card-slider-container .swiper-pagination-bullet-active, .page-separator, .pagination .current, .pagination a.page-numbers:hover, .entry-content ul > li:before, .entry-content ul:not([class])>li:before, .taxonomy-description ul:not([class])>li:before, .btn, .comment-respond .form-submit input, .contact-form .contact_submit, .page-links__item {background-color:#5a80b1}.spoiler-box, .entry-content ol li:before, .entry-content ol:not([class]) li:before, .taxonomy-description ol:not([class]) li:before, .mob-hamburger, .inp:focus, .search-form__text:focus, .entry-content blockquote,
         .comment-respond .comment-form-author input:focus, .comment-respond .comment-form-author textarea:focus, .comment-respond .comment-form-comment input:focus, .comment-respond .comment-form-comment textarea:focus, .comment-respond .comment-form-email input:focus, .comment-respond .comment-form-email textarea:focus, .comment-respond .comment-form-url input:focus, .comment-respond .comment-form-url textarea:focus {border-color:#5a80b1}.entry-content blockquote:before, .spoiler-box__title:after, .sidebar-navigation .menu-item-has-children:after,
        .star-rating--score-1:not(.hover) .star-rating-item:nth-child(1),
        .star-rating--score-2:not(.hover) .star-rating-item:nth-child(1), .star-rating--score-2:not(.hover) .star-rating-item:nth-child(2),
        .star-rating--score-3:not(.hover) .star-rating-item:nth-child(1), .star-rating--score-3:not(.hover) .star-rating-item:nth-child(2), .star-rating--score-3:not(.hover) .star-rating-item:nth-child(3),
        .star-rating--score-4:not(.hover) .star-rating-item:nth-child(1), .star-rating--score-4:not(.hover) .star-rating-item:nth-child(2), .star-rating--score-4:not(.hover) .star-rating-item:nth-child(3), .star-rating--score-4:not(.hover) .star-rating-item:nth-child(4),
        .star-rating--score-5:not(.hover) .star-rating-item:nth-child(1), .star-rating--score-5:not(.hover) .star-rating-item:nth-child(2), .star-rating--score-5:not(.hover) .star-rating-item:nth-child(3), .star-rating--score-5:not(.hover) .star-rating-item:nth-child(4), .star-rating--score-5:not(.hover) .star-rating-item:nth-child(5), .star-rating-item.hover {color:#5a80b1}body {color:#333333}a, .spanlink, .comment-reply-link, .pseudo-link, .root-pseudo-link {color:#428bca}a:hover, a:focus, a:active, .spanlink:hover, .comment-reply-link:hover, .pseudo-link:hover {color:#e66212}.site-header {background-color:#ffffff}.site-header {color:#333333}.site-title, .site-title a {color:#5a80b1}.site-description, .site-description a {color:#666666}.main-navigation, .footer-navigation, .main-navigation ul li .sub-menu, .footer-navigation ul li .sub-menu {background-color:#5a80b1}.main-navigation ul li a, .main-navigation ul li .removed-link, .footer-navigation ul li a, .footer-navigation ul li .removed-link {color:#ffffff}.site-content {background-color:#ffffff}.site-footer {background-color:#ffffff}.site-footer {color:#333333}</style><link rel="preload" href="https://niksongames.ru/wp-content/themes/root/fonts/fontawesome-webfont.ttf" as="font" crossorigin><style type="text/css" media="print">#wpadminbar { display:none; }</style>
	<style type="text/css" media="screen">
	html { margin-top: 32px !important; }
	* html body { margin-top: 32px !important; }
	@media screen and ( max-width: 782px ) {
		html { margin-top: 46px !important; }
		* html body { margin-top: 46px !important; }
	}
</style>
	<link rel="icon" href="https://niksongames.ru/wp-content/uploads/2021/08/cropped-2020-12-10_01-55-34-32x32.png" sizes="32x32" />
<link rel="icon" href="https://niksongames.ru/wp-content/uploads/2021/08/cropped-2020-12-10_01-55-34-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://niksongames.ru/wp-content/uploads/2021/08/cropped-2020-12-10_01-55-34-180x180.png" />
<meta name="msapplication-TileImage" content="https://niksongames.ru/wp-content/uploads/2021/08/cropped-2020-12-10_01-55-34-270x270.png" />
		<style type="text/css" id="wp-custom-css">
			#htmlmap_cats{
	display:none;
}		</style>
		    </head>

<body class="home blog logged-in admin-bar no-customize-support ">

	
		

<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#main">Перейти к контенту</a>

    
    
<header id="masthead" class="site-header container" itemscope itemtype="http://schema.org/WPHeader">
    <div class="site-header-inner ">
        <div class="site-branding">
            <div class="site-logotype">
			<a href="{{ url('/') }}"><img src="{{ asset('images/eac8850e.png') }}" width="210" height="52" alt="NiksonGames"></a>
			</div>
                    </div><!-- .site-branding -->

        
        
                   <div class="top-menu">
                
				<div class="menu-main-container">
				
				@include('layouts.include.menu-main-container')
				
				</div> 
        
        <div class="mob-hamburger"><span></span></div>

                    <div class="mob-search">
<form role="search" method="get" id="searchform_6595" action="https://niksongames.ru/" class="search-form">
    <label class="screen-reader-text" for="s_6595">Поиск: </label>
    <input type="text" value="" name="s" id="s_6595" class="search-form__text">
    <button type="submit" id="searchsubmit_6595" class="search-form__submit"></button>
</form></div>
            </div><!--.site-header-inner-->
</header><!-- #masthead -->
    
    
    
    <nav id="site-navigation" class="main-navigation container" itemscope itemtype="http://schema.org/SiteNavigationElement">
        <div class="main-navigation-inner container">
            <div class="menu-menu-container">
		<ul id="header_menu" class="menu">
		@include('layouts.include.main-navigation-inner')

</ul></div>        </div><!--.main-navigation-inner-->
    </nav><!-- #site-navigation -->

    
	
	
	
	<div id="content" class="site-content container">

        

<div itemscope="" itemtype="http://schema.org/Article">




@yield('content')





<meta itemscope="" itemprop="mainEntityOfPage" itemtype="https://schema.org/WebPage" itemid="https://niksongames.ru/steshenko-nikolaj/" content="Стешенко Николай">
<meta itemprop="dateModified" content="2021-12-07">
<meta itemprop="datePublished" content="2021-09-03T15:29:02+03:00">
<meta itemprop="author" content="Nikson">
<div itemprop="publisher" itemscope="" itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope="" itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
		</main><!-- #main -->
	</div><!-- #primary -->

</div><!-- micro -->




	</div>

    
    
	

    
    
        <div class="footer-navigation container" itemscope itemtype="http://schema.org/SiteNavigationElement">
        <div class="main-navigation-inner ">
            <div class="menu-menu-container"><ul id="footer_menu" class="menu">
			@include('layouts.include.main-navigation-inner')
</ul></div>        </div>
    </div>



    <footer id="site-footer" class="site-footer container " itemscope itemtype="http://schema.org/WPFooter">
        <div class="site-footer-inner ">

            
            <div class="footer-bottom">
                <div class="footer-info">
                    © 2021 NiksonGames
                    
                                    </div><!-- .site-info -->

                
<div class="social-links">
    <div class="social-buttons social-buttons--square social-buttons--circle social-buttons--small">

    <span class="social-button social-button__vk js-link" data-href="aHR0cHM6Ly92ay5jb20vbmlrc29ubXA=" data-target="_blank"></span><span class="social-button social-button__twitter js-link" data-href="aHR0cHM6Ly90d2l0dGVyLmNvbS9uaWtzb25nYW1lcw==" data-target="_blank"></span><span class="social-button social-button__telegram js-link" data-href="aHR0cHM6Ly90Lm1lL25pa3NvbmdhbWVz" data-target="_blank"></span><span class="social-button social-button__youtube js-link" data-href="aHR0cHM6Ly93d3cueW91dHViZS5jb20vY2hhbm5lbC9VQ0N3eG9WR1JGYkl0d3JLc3RsMUFGX2cvZmVhdHVyZWQ=" data-target="_blank"></span><span class="social-button social-button__instagram js-link" data-href="aHR0cHM6Ly93d3cuaW5zdGFncmFtLmNvbS9uaWtzb25nYW1lcy8=" data-target="_blank"></span><span class="social-button social-button__yandexzen js-link" data-href="aHR0cHM6Ly96ZW4ueWFuZGV4LnJ1L2lkLzVhZGE5NTI3NzdkMGU2Zjc0ZDNkMTc0Mw==" data-target="_blank"></span>
    </div>
</div>


                <div class="footer-counters"><!-- Yandex.Metrika informer -->
<a href="https://metrika.yandex.ru/stat/?id=47297964&amp;from=informer"
target="_blank" rel="nofollow"><img src="https://informer.yandex.ru/informer/47297964/3_1_FFFFFFFF_EFEFEFFF_0_pageviews"
style="width:88px; height:31px; border:0;" alt="Яндекс.Метрика" title="Яндекс.Метрика: данные за сегодня (просмотры, визиты и уникальные посетители)" class="ym-advanced-informer" data-cid="47297964" data-lang="ru" /></a>
<!-- /Yandex.Metrika informer -->

<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(47297964, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        trackHash:true
   });
</script>
<!-- /Yandex.Metrika counter --></div>            </div>
        </div><!-- .site-footer-inner -->
    </footer><!-- .site-footer -->


            <button type="button" class="scrolltop js-scrolltop"></button>
    

</div><!-- #page -->



<script type='text/javascript' id='expert-review-scripts-js-extra'>
/* <![CDATA[ */
var expert_review_ajax = {"url":"https:\/\/niksongames.ru\/wp-admin\/admin-ajax.php","nonce":"7397a1d54c","comment_to_scroll_selector":null,"ask_question_link_new_tab":null,"i18n":{"question_popup_name":"\u0418\u043c\u044f","question_popup_email":"Email","question_popup_phone":"\u0422\u0435\u043b\u0435\u0444\u043e\u043d","question_popup_question":"\u0412\u043e\u043f\u0440\u043e\u0441","question_popup_submit":"\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c","question_popup_cancel":"\u041e\u0442\u043c\u0435\u043d\u0430","question_submitted":"\u0412\u043e\u043f\u0440\u043e\u0441 \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d","legacy_form":"\u041d\u0435\u043e\u0431\u0445\u043e\u0434\u0438\u043c\u043e \u043e\u0431\u043d\u043e\u0432\u0438\u0442\u044c \u043a\u043e\u0434 \u0433\u0435\u043d\u0435\u0440\u0430\u0446\u0438\u0438 \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u0441\u043a\u043e\u0439 \u0444\u043e\u0440\u043c\u044b","field_cannot_be_empty":"\u041f\u043e\u043b\u0435 \u043d\u0435 \u043c\u043e\u0436\u0435\u0442 \u0431\u044b\u0442\u044c \u043f\u0443\u0441\u0442\u044b\u043c","field_must_be_checked":"\u041f\u043e\u043b\u0435 \u0434\u043e\u043b\u0436\u043d\u043e \u0431\u044b\u0442\u044c \u043e\u0442\u043c\u0435\u0447\u0435\u043d\u043e","consent":"\u0421\u043e\u0433\u043b\u0430\u0441\u0438\u0435 \u043d\u0430 \u043e\u0431\u0440\u0430\u0431\u043e\u0442\u043a\u0443 \u043f\u0435\u0440\u0441\u043e\u043d\u0430\u043b\u044c\u043d\u044b\u0445 \u0434\u0430\u043d\u043d\u044b\u0445"},"consent":null};
/* ]]> */
</script>
<script  src='https://niksongames.ru/wp-content/plugins/expert-review/assets/public/js/scripts.min.js?ver=1.7.0' id='expert-review-scripts-js'></script>
<script  src='https://niksongames.ru/wp-content/themes/root/assets/js/plugins/lightbox.min.js?ver=3.1.1' id='root-lightbox-js'></script>
<script type='text/javascript' id='root-scripts-js-extra'>
/* <![CDATA[ */
var settings_array = {"rating_text_average":"\u0441\u0440\u0435\u0434\u043d\u0435\u0435","rating_text_from":"\u0438\u0437","lightbox_enabled":"1"};
var wps_ajax = {"url":"https:\/\/niksongames.ru\/wp-admin\/admin-ajax.php","nonce":"7397a1d54c"};
/* ]]> */
</script>
<script  src='https://niksongames.ru/wp-content/themes/root/assets/js/scripts.min.js?ver=3.1.1' id='root-scripts-js'></script>
<script  src='https://niksongames.ru/wp-content/plugins/youtube-embed-plus/scripts/fitvids.min.js?ver=14.0.1.1' id='__ytprefsfitvids__-js'></script>
<script  src='https://niksongames.ru/wp-includes/js/wp-embed.min.js?ver=5.8.2' id='wp-embed-js'></script>
		<script id="kama_spamblock">
			(function(){

				const catch_submit = function( ev ){

					let sbmt = ev.target.closest( '#submit' );

					if( ! sbmt ){
						return;
					}

					let input = document.createElement( 'input' );
					let date = new Date();

					input.value = ''+ date.getUTCDate() + (date.getUTCMonth() + 1) + 'uniq9065';
					input.name = 'ksbn_code';
					input.type = 'hidden';

					sbmt.parentNode.insertBefore( input, sbmt );
				}

				document.addEventListener( 'mousedown', catch_submit );
				document.addEventListener( 'keypress', catch_submit );
			})()
		</script>
		

</body>
</html>