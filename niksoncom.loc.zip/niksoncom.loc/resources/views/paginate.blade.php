@if ($paginator->hasPages())
    <nav style="margin:10px auto;">
        <ul >
             {{-- Previous Page Link --}}
            @if ($paginator->onFirstPage())
                
            @else
                
                    <a class="btn btn-primary" href="{{ $paginator->previousPageUrl() }}" rel="prev" aria-label="@lang('pagination.previous')">Назад</a>
                
            @endif
                
            

            {{-- Pagination Elements --}}
            @foreach ($elements as $element)
                {{-- "Three Dots" Separator --}}
                @if (is_string($element))
                    <span class="page-numbers">{{ $element }}</span>
                @endif

                {{-- Array Of Links --}}
                @if (is_array($element))
                    @foreach ($element as $page => $url)
                        @if ($page == $paginator->currentPage())
                           <span class="btn btn-primary">{{ $page }}</span>
                        @else
                            <a class="btn btn-primary" href="{{ $url }}">{{ $page }}</a>
                        @endif
                    @endforeach
                @endif
            @endforeach

            {{-- Next Page Link --}}
            @if ($paginator->hasMorePages())
                
                    <a class="btn btn-primary" href="{{ $paginator->nextPageUrl() }}" rel="next" aria-label="@lang('pagination.next')">Далее</a>
                
            @else
                
            @endif
        </ul>
    </nav>
@endif
