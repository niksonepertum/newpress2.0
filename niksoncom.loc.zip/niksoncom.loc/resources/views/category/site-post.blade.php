@extends('layouts.castom')

@section('content')

<main id="main" class="site-main">

            
            <div class="breadcrumb" id="breadcrumbs"><span><span><a href="https://niksongames.ru/">Главная страница</a></span></span></div>
            
<article id="post-250" class="post-250 page type-page status-publish ">

    
                    <header class="entry-header">
                                <h1 class="entry-title" itemprop="headline">Карта сайта</h1>                            </header><!-- .entry-header -->
        
        
                    <div class="page-separator"></div>
        
    
    <div class="entry-content" itemprop="articleBody">
        <p id="htmlmap_cats"><span class="cat"><a href="#cat_7">Majestic RolePlay</a> <small>[4]</small></span>, <span class="cat"><a href="#cat_52">Majestic 3 сервер</a> <small>[1]</small></span>, <span class="cat"><a href="#cat_51">Majestic 5 сервер</a> <small>[1]</small></span>, <span class="cat"><a href="#cat_40">Наши релизы</a> <small>[1]</small></span>, <span class="cat"><a href="#cat_10">Новости</a> <small>[2]</small></span>, <span class="cat"><a href="#cat_1">Обзоры видео игр</a> <small>[2]</small></span></p><div id="htmlmap_posts">


@foreach($categorias as $category)

<h2 id="cat_1">{{ $category->title }} <small>[2]</small></h2>

<ul>
@foreach($posts as $post)
@if($post->category->id == $category->id)
<li><small>{{ Date::parse($post->created_at)->format('j F Y г.') }}</small>&nbsp;<a href="{{ route('post.show',  $post->slug) }}">{{ $post->title }}</a></li>
@endif
@endforeach
</ul>
@endforeach
</div>
<!-- toc empty -->    </div><!-- .entry-content -->
</article><!-- #post-## -->








<meta itemscope="" itemprop="mainEntityOfPage" itemtype="https://schema.org/WebPage" itemid="https://niksongames.ru/karta-sajta/" content="Карта сайта">
<meta itemprop="dateModified" content="2021-11-19">
<meta itemprop="datePublished" content="2021-11-19T19:56:32+03:00">
<meta itemprop="author" content="Nikson">
<div itemprop="publisher" itemscope="" itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope="" itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
		</main>

  
@endsection
