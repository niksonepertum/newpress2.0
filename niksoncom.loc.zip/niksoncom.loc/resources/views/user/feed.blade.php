@extends('layouts.blog-feed')

@section('content')

<div class="info"><p>Функционал в разработке</p></div>

@endsection


