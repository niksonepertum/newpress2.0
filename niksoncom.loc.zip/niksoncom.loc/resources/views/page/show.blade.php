@extends('layouts.blog-page')


@section('content')
    
                
					

            
            
				<div class="entry-image entry-image--big">
                <img width="2560" height="1440" src="{{$page->getPosts()}}" class="attachment-full size-full wp-post-image" alt="" loading="lazy" itemprop="image" 
				srcset="{{$page->getPosts()}} 2560w, {{$page->getPosts()}} 300w, {{$page->getPosts()}} 1024w, {{$page->getPosts()}} 768w, {{$page->getPosts()}} 1536w, {{$page->getPosts()}} 2048w, {{$page->getPosts()}} 
				250w, {{$page->getPosts()}} 550w, {{$page->getPosts()}} 800w, {{$page->getPosts()}} 320w, {{$page->getPosts()}} 533w, {{$page->getPosts()}} 889w" sizes="(max-width: 2560px) 100vw, 2560px">        
                <div class="entry-image__title">
                <div class="breadcrumb" id="breadcrumbs"><span><span><a href="https://niksongames.ru/">Главная страница</a></span></span></div>
                <h1 itemprop="headline">{{$page->title}}</h1>
                </div></div>
                
<div id="primary" class="content-area">
		
<main id="main" class="site-main">
<article id="post-139" class="post-139 page type-page status-publish has-post-thumbnail ">
<div class="entry-content" itemprop="articleBody">

      {!!$page->content!!}      
           
</div>
<!-- toc empty -->    
@if( Auth::check() && Auth::user()->role == 4)



                    
<div class="child-categories">
<ul>

                      <li><a  class="child-categories" href="{{ Route('page.edit', $page->id) }}">Редактировать</a></li>
                      <li><a href="#" class="child-categories">Удалить</a></li>

</ul>
                    </div>
                      @endif

</div><!-- .entry-content -->
</article><!-- #post-## -->








<meta itemscope="" itemprop="mainEntityOfPage" itemtype="https://schema.org/WebPage" itemid="https://niksongames.ru/karta-sajta/" content="Карта сайта">
<meta itemprop="dateModified" content="2021-11-19">
<meta itemprop="datePublished" content="2021-11-19T19:56:32+03:00">
<meta itemprop="author" content="Nikson">
<div itemprop="publisher" itemscope="" itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope="" itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="https://niksongames.ru/wp-content/uploads/2021/08/eac8850e.png" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
		</main>

  
	</div>




@endsection
