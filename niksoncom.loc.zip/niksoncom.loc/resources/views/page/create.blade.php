@extends('layouts.castom')

@section('content')

@if(Auth::check() && Auth::user()->role == 4)
@if (count($errors) > 0)
  <div class="alert alert-danger">
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif

                

               
<main id="main" class="site-main">

            
            <div class="breadcrumb" id="breadcrumbs"><span><span><a href="https://niksongames.ru/">Главная страница</a></span></span></div>
            
<article id="post-250" class="post-250 page type-page status-publish ">

    
                    <header class="entry-header">
                                <h1 class="entry-title" itemprop="headline">Добавить страницу</h1>                            </header><!-- .entry-header -->
        
        
                    <div class="page-separator"></div>
        
    
     <form action="{{ Route('page.store') }}" enctype="multipart/form-data" method="post">
    {{ csrf_field() }}
  <div style="width:1090px; padding:10px 0;">
  <label for="create_title" class="form-label">Заголовок</label>
  <input type="text" class="search-form__text" id="create_title" name="title" placeholder="Название статьи">
  
 <label for="create_title" class="form-label">URL Адресс</label>
  <input type="text" class="search-form__text" id="slug" name="slug" placeholder="Например название статьи трансдитом">
  </div>
  
  
  
  <div style="width:1090px; padding:10px 0;">
  <label for="lable-content" class="form-label">Статья</label>
  <textarea id="excerpt1" name="content" cols="45" rows="8"  required="required"></textarea>
  <script>CKEDITOR.replace( 'excerpt1' );</script>
  </div>
  


                   


                    
                    <label for="edit_photo" class="form-label">Текущее фото</label>
                    <label for="create_photo" class="form-label">Изменить фото</label>
                    <input type="file" class="form-control" id="create_photo" name="img" aria-describedby="emailHelp">
                    

                    
                    
					
					<br />


                    <input type="submit" value="Сохранить" class="btn btn-sm btn-outline-secondary">

                </form>

</article>
		</main>



 
                

@else
<div class="alert alert-danger" role="alert">
  Доступ к этой страницы закрыт
</div>
@endif
@endsection