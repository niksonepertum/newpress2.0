@extends('layouts.castom')

@section('content')

@if(Auth::check() && Auth::user()->role == 4)
@if (count($errors) > 0)
  <div class="alert alert-danger">
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif

                

               
<main id="main" class="site-main">

            
            <div class="breadcrumb" id="breadcrumbs"><span><span><a href="https://niksongames.ru/">Главная страница</a></span></span></div>
            
<article id="post-250" class="post-250 page type-page status-publish ">

    
                    <header class="entry-header">
                                <h1 class="entry-title" itemprop="headline">Редактировать статью</h1>                            </header><!-- .entry-header -->
        
        
                    <div class="page-separator"></div>
        
    
     <form action="{{ Route('post.update', $post->id) }}" enctype="multipart/form-data" method="post">
    {{ csrf_field() }}
  <div style="width:1090px; padding:10px 0;">
  <label for="create_title" class="form-label">Заголовок</label>
  <input type="text" class="search-form__text" id="create_title" name="title" placeholder="" value="{{ $post->title }}" aria-describedby="emailHelp">
  
  <small> Заголовок статьи лучше не менять <strong>Изменяется и адресс страницы </strong></small>
  </div>
  <select class="search-form__text" id="inlineFormCustomSelect" name="category_id">

                     @foreach($categories as $category)
                     @if($post->category_id == $category->id)
                     <option value="{{$category->id }}" selected="selected">{{$category->title }}</option>
				     @else
					 <option value="{{$category->id }}">{{$category->title }}</option>
				     @endif
                     @endforeach
                  </select>


  <div style="width:1090px; padding:10px 0;">
  <label for="lable-excerpt" class="form-label">Описание</label>
  <textarea id="excerpt" name="excerpt" cols="45" rows="8" >{{ $post->excerpt }}</textarea>
  <small>До 128 симвалов с пробелами</small>
  <script>CKEDITOR.replace( 'excerpt' );</script>
  </div>
  
  <div style="width:1090px; padding:10px 0;">
  <label for="lable-content" class="form-label">Статья</label>
  <textarea id="excerpt1" name="content" cols="45" rows="8"  required="required">{{ $post->content }}</textarea>
  <script>CKEDITOR.replace( 'excerpt1' );</script>
  </div>
  


                   <label for="iFormCustomSelect" class="form-label">Статус статьи</label>
  <select class="search-form__text" id="iFormCustomSelect" name="is_public">
                   <option value="0">Черновик</option>
                    @if($post->is_public == 1)
                     <option value="{{$post->is_public }}" selected="selected">Опубликовано</option>
				     @else
					 <option value="2">Скрытый</option>
				     @endif
                     
                     <option value="{{ $post->is_public }}">Опубликованый</option>
				     
                     
                  </select>


                    
                    <label for="edit_photo" class="form-label">Текущее фото</label>
                    <img  alt="{{$post->title}}" style="height: 60px; width: 100px; display: block;" src="{{$post->getPosts()}}" id="edit_photo">
                    <label for="create_photo" class="form-label">Изменить фото</label>
                    <input type="file" class="form-control" id="create_photo" name="img" aria-describedby="emailHelp">
                    

                    <input type="hidden" name="_method" value="put">
                    <input type="hidden"  name="user_id" value="{{ $post->user_id }}">
					
					<br /><br />


                    <input type="submit" value="Сохранить" class="btn btn-sm btn-outline-secondary">

                </form>

</article>
		</main>



 
                

@else
<div class="alert alert-danger" role="alert">
  Доступ к этой страницы закрыт
</div>
@endif
@endsection
