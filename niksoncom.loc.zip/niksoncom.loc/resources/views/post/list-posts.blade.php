@extends('layouts.blog')

@section('content')

@if(session('status'))
						<div class="check">
							{{session('status')}}
						</div>
						@endif
						

@foreach ($posts as $post)
@if(!$post->is_public == 0)
 
 
 
<div id="post-258" class="post-box post-258 post type-post status-publish format-standard has-post-thumbnail  category-poslednie-novosti-kompyuternyh-igr tag-ats tag-dlc" itemscope itemtype="http://schema.org/BlogPosting">
	<header class="entry-header"><div class="entry-title" itemprop="name"><span itemprop="headline"><a href="{{ $post->slug }}">{{$post->title}}</a></span></div><div class="entry-meta"><span class="entry-date"><time itemprop="datePublished" datetime="2021-11-19">{{ Date::parse($post->created_at)->format('j F Y г.') }}</time></span><span class="entry-category"><span class="hidden-xs">Рубрика:</span> <a href="{{ route('category.show', ['category' => $post->category->slug]) }}" itemprop="articleSection">{{ $post->category->title }} </a></span>
	<span class="entry-author"><span class="hidden-xs">Автор:</span> <span itemprop="author"><a href="{{ route('user.show', ['user' => $post->author->id]) }}" itemprop="articleSection">{{ $post->author->name }} </a></span></span><span class="entry-meta__info"><span class="entry-meta__comments" title="Комментарии"><span class="fa fa-comment-o"></span> 0</span></span></div></header><div class="entry-image">
	<a href="https://niksongames.ru/ats-dlc-montana-anons/"><img width="770" height="330" src="{{$post->getPosts()}}" class="attachment-thumb-big size-thumb-big wp-post-image" alt="{{$post->title}}" loading="lazy" itemprop="image" srcset="{{$post->getPosts()}}" sizes="(max-width: 770px) 100vw, 770px" /></a></div>
	<div class="post-box__content" itemprop="articleBody">{!! $post->excerpt !!}</div><footer class="post-box__footer"><a href="#" class="entry-footer__more">Читать полностью</a></footer>
            	<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="https://niksongames.ru/ats-dlc-montana-anons/" content="{{$post->title}}">
	<meta itemprop="dateModified" content="2021-11-19">
    <div itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject" style="display: none;"><img itemprop="url image" src="{{$post->getPosts()}}" alt="NiksonGames"></div><meta itemprop="name" content="NiksonGames"><meta itemprop="telephone" content="NiksonGames"><meta itemprop="address" content="https://niksongames.ru"></div>
    
</div>

@endif

 @endforeach
{{ $posts->links("paginate") }}
  
@endsection
