@extends('layouts.blog')

@section('content')

@if(session('status'))
						<div class="alert alert-success">
							{{session('status')}}
						</div>
						@endif
<div class="row">



  @foreach ($posts as $post)


        <div class="col-md-4">
          <div class="card mb-4 box-shadow">
            <img class="card-img-top" data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=[[$post->title]]" alt="{{$post->title}}" style="height: 225px; width: 100%; display: block;" src="{{$post->getPosts()}}" data-holder-rendered="true">
            <div class="card-body">
              <h2>{{$post->title}}</h2>
              <p class="card-text">{{$post->excerpt}}</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <a href="{{ $post->slug }}" class="btn btn-sm btn-outline-secondary">Читать</a>

                </div>
                <small class="text-muted">{{ Date::parse($post->created_at)->format('j F Y г.') }}</small>
              </div>
            </div>
          </div>
        </div>

        @endforeach



      </div>

        {{ $posts->links("paginate") }}
@endsection
