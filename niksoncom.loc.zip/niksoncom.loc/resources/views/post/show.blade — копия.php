@extends('layouts.blog-show')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{$post->title}}</div>

                <div class="card-body">



                    {!! $post->content !!}

                    <br />  <br />



                    @if( Auth::user()->role == 4)



                    <div class="btn-group">


                      <a href="{{ Route('post.edit', $post->id) }}" class="btn btn-sm btn-outline-secondary">Редактировать</a>
                      <a href="#" class="btn btn-sm btn-outline-secondary">Удалить</a>


                    </div>

                      @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
