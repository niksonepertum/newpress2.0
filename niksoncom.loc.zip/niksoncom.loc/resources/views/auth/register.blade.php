@extends('layouts.castom')

@section('content')

<div style="display: flex; align-items: center; justify-content: center;">


                <form method="POST" action="{{ route('register') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="name" class="screen-reader-text">{{ __('Name') }}</label>

                            <div style="margin:10px 0;">
                                <input id="name" type="text" class="search-form__text @error('name') is-invalid @enderror" name="name" placeholder="{{ __('Name') }}"  value="{{ old('name') }}" required autocomplete="name" autofocus>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="screen-reader-text">{{ __('E-Mail Address') }}</label>

                            <div style="margin:10px 0;">
                                <input id="email" type="email" class="search-form__text @error('email') is-invalid @enderror" name="email" placeholder="{{ __('E-Mail Address') }}" value="{{ old('email') }}" required autocomplete="email">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="screen-reader-text">{{ __('Password') }}</label>

                            <div style="margin:10px 0;">
                                <input id="password" type="password" class="search-form__text @error('password') is-invalid @enderror" name="password" placeholder="{{ __('Password') }}" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="screen-reader-text">{{ __('Confirm Password') }}</label>

                            <div style="margin:10px 0;">
                                <input id="password-confirm" type="password" class="search-form__text" name="password_confirmation" placeholder="{{ __('Confirm Password') }}" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div style="margin:10px 0;">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Регистрация') }}
                                </button>
                            </div>
                        </div>
                    </form>

               
					</div>

@endsection


