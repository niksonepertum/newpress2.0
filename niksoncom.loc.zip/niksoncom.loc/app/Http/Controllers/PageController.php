<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Page;



class PageController extends Controller
{


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {












    }


    public function show($slug)
    {
      $page = Page::where('slug', $slug)->first();




        return view('page.show', compact('page'));
    }


  public function create()
	{



		return view('page.create');
	}




  


  

  public function store(Request $request)
  	{
  		$this->validate($request, ['title' => 'required', 'content' => 'required',]);
  		$page = Page::add($request->all());
  		$page->uploadImage($request->file('img'));




  		return redirect()->route('main');
  	}
	
	
	public function edit($id)
	{
		//

		$page = Page::find($id);


                //$categories = Blog_category::all();

		return view('page.edit', compact('page' ));
	}


  public function update(Request $request, $id)
	{
		//


		$this->validate($request, ['title' => 'required', 'content' => 'required', 'excerpt' => 'required', 'img'  =>  'nullable|image'
]);
    $page = Post::find($id);
	  $page->edit($request->all());
		$page->uploadImage($request->file('img'));

		return redirect()->route('main')->with('status', 'Статья успешно обновлена');
	}


}
