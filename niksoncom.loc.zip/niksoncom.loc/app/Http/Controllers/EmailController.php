<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Contact_face;



class EmailController extends Controller
{


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {


    $phone = Contact_face::where('id', 1)->first();


     


    return view('page.phone', compact('phone')); 



    }


    


  


}
