<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Models\Post;
use App\Models\Category;

use Carbon\Carbon;

class PostController extends Controller
{


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

      $posts = Post::orderBy('created_at', 'desc')->paginate(12);
	  









        return view('post.list-posts', compact('posts'));
    }


    public function show($slug)
    {
      $post = Post::where('slug', $slug)->first();
	  




        return view('post.show', compact('post'));
    }






    public function create()
	{
       $categories = category::all();


		return view('post.create', compact('categories'));
	}


  public function store(Request $request)
  	{   
  		$this->validate($request, ['title' => 'required', 'content' => 'required', 'excerpt' => 'required', 'category_id' => 'required', 'user_id' => 'required']);
  		$post = Post::add($request->all());
  		$post->uploadImage($request->file('img'));




  		return redirect()->route('main');
  	}



    public function edit($id)
	{
		//

		$post = Post::find($id);
		$categories = Category::all();


                //$categories = Blog_category::all();

		return view('post.edit', compact('post', 'categories' ));
	}


  public function update(Request $request, $id)
	{
		//


		$this->validate($request, ['title' => 'required', 'content' => 'required', 'excerpt' => 'required', 'img'  =>  'nullable|image'
]);
    $post = Post::find($id);
	  $post->edit($request->all());
		$post->uploadImage($request->file('img'));

		return redirect()->route('main')->with('status', 'Статья успешно обновлена');
	}


}
