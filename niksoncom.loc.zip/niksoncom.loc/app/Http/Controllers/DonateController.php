<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Donate;



class DonateController extends Controller
{


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {


    



    }



	
	
	public function donate()
    {


    $donate = donate::where('id', 1)->first();


     


    return view('donat.donate', compact('donate')); 



    }


public function thank()
    {


    $you = donate::where('id', 2)->first();


     


    return view('donat.thank', compact('you')); 


     


    


    }
    


  


}
