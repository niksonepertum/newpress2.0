<?php

namespace App\Models;


use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    use HasFactory;

     protected  $fillable = ['title',  'content', 'img', 'slug', 'sdesc', 'skey', 'updated_at', 'created_at'];

    use HasSlug;

       /**
        * Get the options for generating the slug.
        */
       public function getSlugOptions() : SlugOptions
       {
           
			   if($this->slug ==  $this->title){
				   return $this->slug;
			   }else{
				   return SlugOptions::create()->generateSlugsFrom('title')->saveSlugsTo('slug');
			   }
              
       }



       public static function Add($fillable)
	{
		$page = new static;
		$page->fill($fillable);
        $page->save();

		return $page;
	}


    public function uploadImage($image)
    {
    	if($image == null) { return; }

    	
    	$filename = str::random(10) . '.' . $image->extension();
    	$image->storeAs('uploads/', $filename);
    	$this->img = $filename;
    	$this->save();
    }

  	

    public function getPosts()
	{
		if ($this->img == null) {
			return;
		}

		return '/uploads/posts/' . $this->img;
	}
}



// {{$post->getPosts}}
