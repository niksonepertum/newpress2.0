<?php

namespace App\Models;

use Illuminate\Support\Facades\Storage;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;
use App\Models\Category;
use App\Models\User;


class Post extends Model
{
    use HasFactory;

     protected  $fillable = ['title', 'excerpt', 'content', 'img', 'slug', 'user_id', 'category_id', 'is_public', 'updated_at', 'created_at'];

    

       /**
        * Get the options for generating the slug.
        */
       



       public static function Add($fillable)
	{
		$post = new static;
		$post->fill($fillable);
        $post->save();

		return $post;
	}



  public function edit($fields)
 	{
 		$this->fill($fields);
 		$this->save();
 	}





   public function uploadImage($image)
    {
    	if($image == null) { return; }

    	$this->removeImage();
    	$filename = str::random(10) . '.' . $image->extension();
    	$image->storeAs('uploads/posts/', $filename);
    	$this->img = $filename;
    	$this->save();
    }

  	public function removeImage()
  	{
  		if ($this->img != null) {
  			Storage::delete('/uploads/posts/' . $this->img);
  		}
  	}

    public function getPosts()
	{
		if ($this->img == null) {
			return '/images/not-img.jpg';
		}

		return '/uploads/posts/' . $this->img;
	}
	
	public function category()
    {
    	return $this->belongsTo(Category::class);	
    }
	
	public function author()
    {
    	return $this->belongsTo(User::class,  'user_id', 'id');	
    }
}



//  HasMany{{$post->getPosts}}
