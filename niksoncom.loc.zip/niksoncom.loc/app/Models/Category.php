<?php

namespace App\Models;



use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\models\Post;
class Category extends Model
{
	
    use HasFactory;

     protected  $fillable = ['title', 'description', 'slug', 'parent_id', 'updated_at', 'created_at'];
	 
	 
	 
	 public function posts() {
        return $this->hasMany(Post::class,  'category_id');
    }

   
}






// HasMany{{$post->getPosts}}
